import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Star, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";

export default function ActivityFeed() {
  const { isAuthenticated } = useAuth();
  
  const { data: activities, isLoading } = useQuery({
    queryKey: ["/api/activities"],
    enabled: isAuthenticated,
  });

  if (isLoading) {
    return (
      <Card className="neumorphic border-0">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center space-x-4 p-4 bg-muted rounded-xl animate-pulse">
                <div className="w-10 h-10 bg-gray-300 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-300 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded"></div>
                </div>
                <div className="w-16 h-3 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'resume_created':
        return <Check className="w-5 h-5 text-green-600" />;
      case 'badge_earned':
        return <Star className="w-5 h-5 text-blue-600" />;
      case 'study_joined':
        return <Users className="w-5 h-5 text-purple-600" />;
      default:
        return <Check className="w-5 h-5 text-green-600" />;
    }
  };

  const getActivityBgColor = (type: string) => {
    switch (type) {
      case 'resume_created':
        return 'bg-green-100';
      case 'badge_earned':
        return 'bg-blue-100';
      case 'study_joined':
        return 'bg-purple-100';
      default:
        return 'bg-green-100';
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    return `${Math.floor(diffInHours / 24)} days ago`;
  };

  // Default activities if none exist
  const defaultActivities = [
    {
      id: '1',
      activityType: 'badge_earned',
      title: 'Welcome to Gradify!',
      description: 'You joined Gradify and started your career journey',
      createdAt: new Date().toISOString(),
    }
  ];

  const displayActivities = Array.isArray(activities) && activities.length > 0 ? activities : defaultActivities;

  return (
    <Card className="neumorphic border-0">
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {displayActivities.slice(0, 5).map((activity: any) => (
            <div key={activity.id} className="flex items-center space-x-4 p-4 bg-muted rounded-xl">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getActivityBgColor(activity.activityType)}`}>
                {getActivityIcon(activity.activityType)}
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">{activity.title}</p>
                <p className="text-sm text-secondary">{activity.description}</p>
              </div>
              <span className="text-sm text-secondary">
                {formatTimeAgo(activity.createdAt)}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
