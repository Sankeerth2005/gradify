import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LucideIcon } from "lucide-react";

interface ToolCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  status?: 'available' | 'premium' | 'coming-soon';
  onClick?: () => void;
  progress?: number;
}

export function ToolCard({ 
  icon: Icon, 
  title, 
  description, 
  status = 'available', 
  onClick,
  progress 
}: ToolCardProps) {
  return (
    <Card className="clean-card p-0 cursor-pointer" onClick={onClick}>
      <CardHeader className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
            <Icon className="w-6 h-6 text-blue-600" />
          </div>
          {status !== 'available' && (
            <Badge variant={status === 'premium' ? 'default' : 'secondary'} className="text-xs">
              {status === 'premium' ? 'Premium' : 'Coming Soon'}
            </Badge>
          )}
        </div>
        <CardTitle className="text-xl font-bold text-gray-900 mb-2">{title}</CardTitle>
        <CardDescription className="text-gray-600 leading-relaxed">{description}</CardDescription>
      </CardHeader>
      {progress !== undefined && (
        <CardContent className="px-6 pb-6 pt-0">
          <div className="space-y-3">
            <div className="flex justify-between text-sm font-medium">
              <span className="text-gray-600">Progress</span>
              <span className="text-gray-900">{progress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </CardContent>
      )}
      {onClick && (
        <CardContent className="px-6 pb-6 pt-0">
          <Button className="btn-clean w-full">
            Get Started
          </Button>
        </CardContent>
      )}
    </Card>
  );
}