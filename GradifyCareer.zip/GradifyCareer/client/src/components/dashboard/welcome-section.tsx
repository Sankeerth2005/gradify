import { useAuth } from "@/hooks/useAuth";

interface WelcomeSectionProps {
  resumeCount: number;
  badgeCount: number;
  taskCount: number;
}

export default function WelcomeSection({ resumeCount, badgeCount, taskCount }: WelcomeSectionProps) {
  const { user } = useAuth();
  
  const userName = (user as any)?.firstName || 'there';
  const atsScore = resumeCount > 0 ? Math.floor(Math.random() * 20) + 80 : 0; // Mock ATS score
  const toolsUsed = Math.min(resumeCount + badgeCount + Math.floor(taskCount / 2), 15);

  return (
    <div className="gradient-primary-accent rounded-2xl p-6 lg:p-8 text-white neumorphic">
      <h1 className="text-2xl lg:text-3xl font-bold mb-2">Welcome back, {userName}! 👋</h1>
      <p className="text-lg opacity-90 mb-4">Ready to advance your career today?</p>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-6">
        <div className="bg-white/20 rounded-xl p-4 backdrop-blur-sm">
          <h3 className="font-semibold mb-1">Resume Score</h3>
          <p className="text-2xl font-bold">{atsScore}/100</p>
        </div>
        <div className="bg-white/20 rounded-xl p-4 backdrop-blur-sm">
          <h3 className="font-semibold mb-1">Tools Used</h3>
          <p className="text-2xl font-bold">{toolsUsed}/15</p>
        </div>
        <div className="bg-white/20 rounded-xl p-4 backdrop-blur-sm">
          <h3 className="font-semibold mb-1">Badges Earned</h3>
          <p className="text-2xl font-bold">{badgeCount}</p>
        </div>
      </div>
    </div>
  );
}
