import { Link, useLocation } from "wouter";
import { LayoutDashboard, Brain, Microscope, Users, User } from "lucide-react";
import { cn } from "@/lib/utils";

const mobileNavItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/career-tools", icon: Brain, label: "Career" },
  { href: "/research", icon: Microscope, label: "Research" },
  { href: "/community", icon: Users, label: "Community" },
  { href: "/profile", icon: User, label: "Profile" },
];

export default function MobileNav() {
  const [location] = useLocation();

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border neumorphic">
      <div className="grid grid-cols-5 py-2">
        {mobileNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href || 
            (item.href !== "/" && location.startsWith(item.href));
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center py-2 px-1 transition-colors",
                isActive ? "text-primary" : "text-secondary"
              )}
            >
              <Icon className="w-5 h-5 mb-1" />
              <span className="text-xs">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
