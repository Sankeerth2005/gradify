import { Link, useLocation } from "wouter";
import { GraduationCap, LayoutDashboard, Brain, Microscope, Globe, Users, CreditCard, HelpCircle } from "lucide-react";
import { cn } from "@/lib/utils";

const sidebarItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/career-tools", icon: Brain, label: "Career Tools" },
  { href: "/research", icon: Microscope, label: "Research" },
  { href: "/branding", icon: Globe, label: "Branding" },
  { href: "/community", icon: Users, label: "Community" },
  { href: "/subscription", icon: CreditCard, label: "Subscription" },
  { href: "/help", icon: HelpCircle, label: "Help Center" },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-card neumorphic fixed h-full z-30 lg:relative lg:translate-x-0 transform -translate-x-full transition-transform duration-300 ease-in-out" id="sidebar">
      <div className="p-6 border-b border-border">
        <Link href="/" className="flex items-center space-x-2">
          <div className="w-8 h-8 gradient-primary-accent rounded-lg flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold text-foreground">Gradify</span>
        </Link>
      </div>
      
      <nav className="p-4 space-y-2">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href || 
            (item.href !== "/" && location.startsWith(item.href));
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center space-x-3 p-3 rounded-2xl transition-colors",
                isActive
                  ? "bg-primary text-primary-foreground neumorphic-inset"
                  : "text-secondary hover:bg-muted"
              )}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
