import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { apiRequest } from '@/lib/queryClient';
import Sidebar from '@/components/layout/sidebar';
import Header from '@/components/layout/header';
import MobileNav from '@/components/layout/mobile-nav';
import { 
  FileText, 
  Brain, 
  Target, 
  MessageSquare, 
  Award,
  TrendingUp,
  Download,
  Sparkles,
  CheckCircle,
  AlertCircle,
  Clock,
  Users,
  Search,
  Zap,
  Shield,
  BookOpen,
  PenTool,
  Linkedin,
  RefreshCw,
  Upload,
  Eye,
  Play
} from 'lucide-react';

interface ResumeAnalysis {
  atsScore: number;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  keywordOptimization: {
    missing: string[];
    present: string[];
  };
  sectionAnalysis: {
    summary: { score: number; feedback: string };
    experience: { score: number; feedback: string };
    skills: { score: number; feedback: string };
    education: { score: number; feedback: string };
  };
  overallFeedback: string;
}

export default function AICareerTools() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('resume-analyzer');
  
  // Form states
  const [resumeText, setResumeText] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [currentRole, setCurrentRole] = useState('');
  const [targetRole, setTargetRole] = useState('');
  const [experience, setExperience] = useState('');
  const [skills, setSkills] = useState('');
  const [linkedinProfile, setLinkedinProfile] = useState('');
  const [textToCheck, setTextToCheck] = useState('');
  const [textToHumanize, setTextToHumanize] = useState('');
  const [interviewDifficulty, setInterviewDifficulty] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');

  // Results states
  const [resumeAnalysis, setResumeAnalysis] = useState<ResumeAnalysis | null>(null);
  const [generatedCoverLetter, setGeneratedCoverLetter] = useState('');
  const [careerRoadmap, setCareerRoadmap] = useState(null);
  const [interviewQuestions, setInterviewQuestions] = useState(null);
  const [linkedinOptimization, setLinkedinOptimization] = useState(null);
  const [plagiarismResult, setPlagiarismResult] = useState(null);
  const [humanizedText, setHumanizedText] = useState('');

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch user data
  const { data: resumes = [] } = useQuery({
    queryKey: ['/api/resumes'],
    enabled: isAuthenticated
  });

  const { data: subscriptionStatus } = useQuery({
    queryKey: ['/api/subscription/status'],
    enabled: isAuthenticated
  });

  // Resume Analysis Mutation
  const analyzeResumeMutation = useMutation({
    mutationFn: async ({ resumeId, jobDescription }: { resumeId?: string; jobDescription?: string }) => {
      if (resumeId) {
        return await apiRequest('POST', `/api/resumes/${resumeId}/analyze`, { jobDescription });
      } else {
        // For direct text analysis, we'll create a temp analysis
        const response = await fetch('/api/ai/analyze-resume-text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ resumeText, jobDescription })
        });
        return await response.json();
      }
    },
    onSuccess: (data) => {
      setResumeAnalysis(data);
      toast({
        title: "Analysis Complete!",
        description: `ATS Score: ${data.atsScore}/100`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Analysis Failed",
        description: error.message || "Failed to analyze resume",
        variant: "destructive",
      });
    }
  });

  // Cover Letter Generation Mutation
  const generateCoverLetterMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/cover-letters/generate', {
        resumeText,
        jobDescription,
        companyName
      });
    },
    onSuccess: (data) => {
      setGeneratedCoverLetter(data.content);
      toast({
        title: "Cover Letter Generated!",
        description: "Your personalized cover letter is ready.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate cover letter",
        variant: "destructive",
      });
    }
  });

  // Career Roadmap Generation Mutation
  const generateRoadmapMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/roadmaps/generate', {
        currentRole,
        targetRole,
        experience: parseInt(experience) || 0,
        skills: skills.split(',').map(s => s.trim()).filter(Boolean)
      });
    },
    onSuccess: (data) => {
      setCareerRoadmap(data.data);
      toast({
        title: "Roadmap Created!",
        description: "Your personalized career roadmap is ready.",
      });
    }
  });

  // Interview Questions Generation Mutation
  const generateInterviewMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/interview-sessions/generate', {
        jobDescription,
        difficulty: interviewDifficulty
      });
    },
    onSuccess: (data) => {
      setInterviewQuestions(data.questions);
      toast({
        title: "Interview Questions Ready!",
        description: `Generated ${interviewDifficulty} level questions.`,
      });
    }
  });

  // LinkedIn Optimization Mutation
  const optimizeLinkedinMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/profile/optimize-linkedin', {
        currentProfile: linkedinProfile,
        targetRole
      });
    },
    onSuccess: (data) => {
      setLinkedinOptimization(data);
      toast({
        title: "LinkedIn Optimization Complete!",
        description: "Your profile improvements are ready.",
      });
    }
  });

  // Plagiarism Check Mutation
  const checkPlagiarismMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/research/plagiarism-check', {
        text: textToCheck,
        title: 'Plagiarism Analysis'
      });
    },
    onSuccess: (data) => {
      setPlagiarismResult(data.analysis);
      toast({
        title: "Plagiarism Check Complete!",
        description: `Originality Score: ${data.analysis.originalityScore}%`,
      });
    }
  });

  // Text Humanization Mutation
  const humanizeTextMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/research/humanize-text', {
        text: textToHumanize
      });
    },
    onSuccess: (data) => {
      setHumanizedText(data.humanizedText);
      toast({
        title: "Text Humanized!",
        description: "Your text has been made more natural and human-like.",
      });
    }
  });

  const isPremiumUser = subscriptionStatus?.hasActiveSubscription;

  const FeatureCard = ({ title, description, icon: Icon, children, isPremium = false }: any) => (
    <Card className="relative overflow-hidden">
      {isPremium && !isPremiumUser && (
        <div className="absolute top-0 right-0 bg-gradient-to-l from-purple-500 to-pink-500 text-white px-3 py-1 text-xs">
          Premium
        </div>
      )}
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <Icon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
          </div>
          <div>
            <CardTitle className="text-lg">{title}</CardTitle>
            <CardDescription className="text-sm">{description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isPremium && !isPremiumUser ? (
          <div className="text-center py-8 space-y-4">
            <Shield className="h-12 w-12 text-gray-400 mx-auto" />
            <p className="text-gray-600 dark:text-gray-400">
              Upgrade to Premium to access this advanced feature
            </p>
            <Button 
              onClick={() => window.location.href = '/subscription'}
              className="bg-gradient-to-r from-purple-500 to-pink-500"
            >
              Upgrade Now
            </Button>
          </div>
        ) : (
          children
        )}
      </CardContent>
    </Card>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <MobileNav />
        
        <main className="flex-1 p-6 lg:ml-64 lg:mr-0">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                AI-Powered Career Tools
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Advanced AI tools to accelerate your career development journey
              </p>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 w-full">
                <TabsTrigger value="resume-analyzer" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  <span className="hidden sm:inline">Resume AI</span>
                </TabsTrigger>
                <TabsTrigger value="cover-letter" className="flex items-center gap-2">
                  <PenTool className="h-4 w-4" />
                  <span className="hidden sm:inline">Cover Letter</span>
                </TabsTrigger>
                <TabsTrigger value="roadmap" className="flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  <span className="hidden sm:inline">Roadmap</span>
                </TabsTrigger>
                <TabsTrigger value="interview" className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  <span className="hidden sm:inline">Interview</span>
                </TabsTrigger>
                <TabsTrigger value="linkedin" className="flex items-center gap-2">
                  <Linkedin className="h-4 w-4" />
                  <span className="hidden sm:inline">LinkedIn</span>
                </TabsTrigger>
                <TabsTrigger value="research" className="flex items-center gap-2">
                  <Search className="h-4 w-4" />
                  <span className="hidden sm:inline">Research</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="resume-analyzer" className="space-y-6">
                <FeatureCard 
                  title="AI Resume Analyzer" 
                  description="Get detailed ATS analysis and optimization suggestions"
                  icon={Brain}
                >
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="resume-text">Resume Content</Label>
                      <Textarea
                        id="resume-text"
                        placeholder="Paste your resume content here..."
                        value={resumeText}
                        onChange={(e) => setResumeText(e.target.value)}
                        className="min-h-[200px]"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="job-desc">Job Description (Optional)</Label>
                      <Textarea
                        id="job-desc"
                        placeholder="Paste the job description for targeted analysis..."
                        value={jobDescription}
                        onChange={(e) => setJobDescription(e.target.value)}
                        className="min-h-[150px]"
                      />
                    </div>

                    <Button 
                      onClick={() => analyzeResumeMutation.mutate({ jobDescription })}
                      disabled={!resumeText || analyzeResumeMutation.isPending}
                      className="w-full"
                    >
                      {analyzeResumeMutation.isPending ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Brain className="h-4 w-4 mr-2" />
                          Analyze Resume
                        </>
                      )}
                    </Button>

                    {resumeAnalysis && (
                      <div className="space-y-4 mt-6">
                        <div className="flex items-center gap-4">
                          <div className="text-center">
                            <div className="text-3xl font-bold text-blue-600">
                              {resumeAnalysis.atsScore}
                            </div>
                            <div className="text-sm text-gray-600">ATS Score</div>
                          </div>
                          <Progress value={resumeAnalysis.atsScore} className="flex-1" />
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-green-600 flex items-center gap-2">
                                <CheckCircle className="h-5 w-5" />
                                Strengths
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ul className="space-y-1">
                                {resumeAnalysis.strengths.map((strength, index) => (
                                  <li key={index} className="text-sm">• {strength}</li>
                                ))}
                              </ul>
                            </CardContent>
                          </Card>

                          <Card>
                            <CardHeader>
                              <CardTitle className="text-red-600 flex items-center gap-2">
                                <AlertCircle className="h-5 w-5" />
                                Areas to Improve
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ul className="space-y-1">
                                {resumeAnalysis.weaknesses.map((weakness, index) => (
                                  <li key={index} className="text-sm">• {weakness}</li>
                                ))}
                              </ul>
                            </CardContent>
                          </Card>
                        </div>

                        <Card>
                          <CardHeader>
                            <CardTitle>Recommendations</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ul className="space-y-2">
                              {resumeAnalysis.recommendations.map((rec, index) => (
                                <li key={index} className="text-sm p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                                  {rec}
                                </li>
                              ))}
                            </ul>
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </div>
                </FeatureCard>
              </TabsContent>

              <TabsContent value="cover-letter" className="space-y-6">
                <FeatureCard 
                  title="AI Cover Letter Generator" 
                  description="Create personalized cover letters for any job application"
                  icon={PenTool}
                >
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="company">Company Name</Label>
                      <Input
                        id="company"
                        placeholder="e.g., Google, Microsoft, Apple..."
                        value={companyName}
                        onChange={(e) => setCompanyName(e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="job-description">Job Description</Label>
                      <Textarea
                        id="job-description"
                        placeholder="Paste the complete job description here..."
                        value={jobDescription}
                        onChange={(e) => setJobDescription(e.target.value)}
                        className="min-h-[150px]"
                      />
                    </div>

                    <Button 
                      onClick={() => generateCoverLetterMutation.mutate()}
                      disabled={!companyName || !jobDescription || generateCoverLetterMutation.isPending}
                      className="w-full"
                    >
                      {generateCoverLetterMutation.isPending ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Sparkles className="h-4 w-4 mr-2" />
                          Generate Cover Letter
                        </>
                      )}
                    </Button>

                    {generatedCoverLetter && (
                      <div className="mt-6">
                        <Label>Generated Cover Letter</Label>
                        <Textarea
                          value={generatedCoverLetter}
                          onChange={(e) => setGeneratedCoverLetter(e.target.value)}
                          className="min-h-[300px] mt-2"
                        />
                        <Button 
                          onClick={() => navigator.clipboard.writeText(generatedCoverLetter)}
                          className="mt-2"
                          variant="outline"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Copy to Clipboard
                        </Button>
                      </div>
                    )}
                  </div>
                </FeatureCard>
              </TabsContent>

              <TabsContent value="roadmap" className="space-y-6">
                <FeatureCard 
                  title="Career Roadmap Generator" 
                  description="Get a personalized roadmap to reach your career goals"
                  icon={Target}
                  isPremium
                >
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="current-role">Current Role</Label>
                        <Input
                          id="current-role"
                          placeholder="e.g., Junior Developer"
                          value={currentRole}
                          onChange={(e) => setCurrentRole(e.target.value)}
                        />
                      </div>

                      <div>
                        <Label htmlFor="target-role">Target Role</Label>
                        <Input
                          id="target-role"
                          placeholder="e.g., Senior Software Engineer"
                          value={targetRole}
                          onChange={(e) => setTargetRole(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="years-exp">Years of Experience</Label>
                        <Input
                          id="years-exp"
                          type="number"
                          placeholder="e.g., 2"
                          value={experience}
                          onChange={(e) => setExperience(e.target.value)}
                        />
                      </div>

                      <div>
                        <Label htmlFor="current-skills">Current Skills (comma-separated)</Label>
                        <Input
                          id="current-skills"
                          placeholder="e.g., JavaScript, React, Node.js"
                          value={skills}
                          onChange={(e) => setSkills(e.target.value)}
                        />
                      </div>
                    </div>

                    <Button 
                      onClick={() => generateRoadmapMutation.mutate()}
                      disabled={!currentRole || !targetRole || generateRoadmapMutation.isPending}
                      className="w-full"
                    >
                      {generateRoadmapMutation.isPending ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Creating Roadmap...
                        </>
                      ) : (
                        <>
                          <Target className="h-4 w-4 mr-2" />
                          Generate Career Roadmap
                        </>
                      )}
                    </Button>

                    {careerRoadmap && (
                      <div className="mt-6 space-y-4">
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                          <h3 className="font-semibold text-blue-800 dark:text-blue-200">
                            Estimated Timeline: {(careerRoadmap as any).timeframe}
                          </h3>
                        </div>

                        <div className="space-y-4">
                          {(careerRoadmap as any).phases?.map((phase: any, index: number) => (
                            <Card key={index}>
                              <CardHeader>
                                <CardTitle className="text-lg">{phase.phase}</CardTitle>
                                <CardDescription>Duration: {phase.duration}</CardDescription>
                              </CardHeader>
                              <CardContent className="space-y-3">
                                <div>
                                  <h4 className="font-medium mb-2">Goals:</h4>
                                  <ul className="list-disc list-inside space-y-1 text-sm">
                                    {phase.goals?.map((goal: string, idx: number) => (
                                      <li key={idx}>{goal}</li>
                                    ))}
                                  </ul>
                                </div>
                                <div>
                                  <h4 className="font-medium mb-2">Skills to Acquire:</h4>
                                  <div className="flex flex-wrap gap-2">
                                    {phase.skillsToAcquire?.map((skill: string, idx: number) => (
                                      <Badge key={idx} variant="secondary">{skill}</Badge>
                                    ))}
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </FeatureCard>
              </TabsContent>

              <TabsContent value="interview" className="space-y-6">
                <FeatureCard 
                  title="AI Interview Preparation" 
                  description="Generate tailored interview questions and practice scenarios"
                  icon={MessageSquare}
                  isPremium
                >
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="interview-job-desc">Job Description</Label>
                      <Textarea
                        id="interview-job-desc"
                        placeholder="Paste the job description to get relevant interview questions..."
                        value={jobDescription}
                        onChange={(e) => setJobDescription(e.target.value)}
                        className="min-h-[120px]"
                      />
                    </div>

                    <div>
                      <Label htmlFor="difficulty">Interview Difficulty</Label>
                      <Select value={interviewDifficulty} onValueChange={(value: any) => setInterviewDifficulty(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="beginner">Beginner</SelectItem>
                          <SelectItem value="intermediate">Intermediate</SelectItem>
                          <SelectItem value="advanced">Advanced</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button 
                      onClick={() => generateInterviewMutation.mutate()}
                      disabled={!jobDescription || generateInterviewMutation.isPending}
                      className="w-full"
                    >
                      {generateInterviewMutation.isPending ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Generating Questions...
                        </>
                      ) : (
                        <>
                          <Play className="h-4 w-4 mr-2" />
                          Generate Interview Questions
                        </>
                      )}
                    </Button>

                    {interviewQuestions && (
                      <div className="mt-6 space-y-4">
                        {Object.entries(interviewQuestions as any).map(([category, questions]: [string, any]) => (
                          <Card key={category}>
                            <CardHeader>
                              <CardTitle className="capitalize">{category} Questions</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                              {questions.map((q: any, idx: number) => (
                                <div key={idx} className="p-3 border rounded-lg">
                                  <p className="font-medium mb-2">{q.question}</p>
                                  {q.hint && (
                                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                                      <strong>Hint:</strong> {q.hint}
                                    </p>
                                  )}
                                  {q.framework && (
                                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                                      <strong>Framework:</strong> {q.framework}
                                    </p>
                                  )}
                                  <p className="text-sm text-blue-600 dark:text-blue-400">
                                    <strong>Expected Answer:</strong> {q.expectedAnswer}
                                  </p>
                                </div>
                              ))}
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>
                </FeatureCard>
              </TabsContent>

              <TabsContent value="linkedin" className="space-y-6">
                <FeatureCard 
                  title="LinkedIn Profile Optimizer" 
                  description="Optimize your LinkedIn profile for better visibility and opportunities"
                  icon={Linkedin}
                  isPremium
                >
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="linkedin-profile">Current LinkedIn Profile</Label>
                      <Textarea
                        id="linkedin-profile"
                        placeholder="Paste your current LinkedIn summary and experience here..."
                        value={linkedinProfile}
                        onChange={(e) => setLinkedinProfile(e.target.value)}
                        className="min-h-[200px]"
                      />
                    </div>

                    <div>
                      <Label htmlFor="linkedin-target-role">Target Role</Label>
                      <Input
                        id="linkedin-target-role"
                        placeholder="e.g., Product Manager, Data Scientist"
                        value={targetRole}
                        onChange={(e) => setTargetRole(e.target.value)}
                      />
                    </div>

                    <Button 
                      onClick={() => optimizeLinkedinMutation.mutate()}
                      disabled={!linkedinProfile || !targetRole || optimizeLinkedinMutation.isPending}
                      className="w-full"
                    >
                      {optimizeLinkedinMutation.isPending ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Optimizing...
                        </>
                      ) : (
                        <>
                          <Linkedin className="h-4 w-4 mr-2" />
                          Optimize LinkedIn Profile
                        </>
                      )}
                    </Button>

                    {linkedinOptimization && (
                      <div className="mt-6 space-y-4">
                        <Card>
                          <CardHeader>
                            <CardTitle>Optimized Headline</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="p-3 bg-gray-50 dark:bg-gray-800 rounded border">
                              {(linkedinOptimization as any).headline}
                            </p>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader>
                            <CardTitle>Enhanced Summary</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded border">
                              <p className="whitespace-pre-line">{(linkedinOptimization as any).summary}</p>
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader>
                            <CardTitle>Keywords to Add</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="flex flex-wrap gap-2">
                              {(linkedinOptimization as any).keywordsToAdd?.map((keyword: string, idx: number) => (
                                <Badge key={idx} variant="outline">{keyword}</Badge>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </div>
                </FeatureCard>
              </TabsContent>

              <TabsContent value="research" className="space-y-6">
                <div className="grid lg:grid-cols-2 gap-6">
                  <FeatureCard 
                    title="Plagiarism Detector" 
                    description="Advanced AI-powered plagiarism and originality analysis"
                    icon={Search}
                    isPremium
                  >
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="text-check">Text to Check</Label>
                        <Textarea
                          id="text-check"
                          placeholder="Paste your text here for plagiarism analysis..."
                          value={textToCheck}
                          onChange={(e) => setTextToCheck(e.target.value)}
                          className="min-h-[200px]"
                        />
                      </div>

                      <Button 
                        onClick={() => checkPlagiarismMutation.mutate()}
                        disabled={!textToCheck || checkPlagiarismMutation.isPending}
                        className="w-full"
                      >
                        {checkPlagiarismMutation.isPending ? (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Search className="h-4 w-4 mr-2" />
                            Check Plagiarism
                          </>
                        )}
                      </Button>

                      {plagiarismResult && (
                        <div className="space-y-4">
                          <div className="flex items-center gap-4">
                            <div className="text-center">
                              <div className="text-2xl font-bold text-green-600">
                                {(plagiarismResult as any).originalityScore}%
                              </div>
                              <div className="text-sm text-gray-600">Originality</div>
                            </div>
                            <Progress value={(plagiarismResult as any).originalityScore} className="flex-1" />
                          </div>

                          <div className="p-3 rounded-lg border">
                            <div className="flex items-center gap-2 mb-2">
                              <div className={`w-3 h-3 rounded-full ${
                                (plagiarismResult as any).riskLevel === 'low' ? 'bg-green-500' :
                                (plagiarismResult as any).riskLevel === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
                              }`} />
                              <span className="font-medium capitalize">
                                {(plagiarismResult as any).riskLevel} Risk
                              </span>
                            </div>
                            
                            {(plagiarismResult as any).suggestions && (
                              <div>
                                <h4 className="font-medium mb-2">Suggestions:</h4>
                                <ul className="text-sm space-y-1">
                                  {(plagiarismResult as any).suggestions.map((suggestion: string, idx: number) => (
                                    <li key={idx}>• {suggestion}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </FeatureCard>

                  <FeatureCard 
                    title="AI Text Humanizer" 
                    description="Make AI-generated text sound more natural and human-like"
                    icon={RefreshCw}
                    isPremium
                  >
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="text-humanize">AI-Generated Text</Label>
                        <Textarea
                          id="text-humanize"
                          placeholder="Paste AI-generated text to make it more human-like..."
                          value={textToHumanize}
                          onChange={(e) => setTextToHumanize(e.target.value)}
                          className="min-h-[200px]"
                        />
                      </div>

                      <Button 
                        onClick={() => humanizeTextMutation.mutate()}
                        disabled={!textToHumanize || humanizeTextMutation.isPending}
                        className="w-full"
                      >
                        {humanizeTextMutation.isPending ? (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            Humanizing...
                          </>
                        ) : (
                          <>
                            <Zap className="h-4 w-4 mr-2" />
                            Humanize Text
                          </>
                        )}
                      </Button>

                      {humanizedText && (
                        <div className="mt-4">
                          <Label>Humanized Text</Label>
                          <Textarea
                            value={humanizedText}
                            onChange={(e) => setHumanizedText(e.target.value)}
                            className="min-h-[200px] mt-2"
                          />
                          <Button 
                            onClick={() => navigator.clipboard.writeText(humanizedText)}
                            className="mt-2"
                            variant="outline"
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Copy Result
                          </Button>
                        </div>
                      )}
                    </div>
                  </FeatureCard>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}