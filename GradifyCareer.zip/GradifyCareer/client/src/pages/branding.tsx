import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Globe, Linkedin, Github, Share2, ExternalLink, BarChart3 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useState } from "react";

export default function Branding() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [linkedinUrl, setLinkedinUrl] = useState("");
  const [githubUrl, setGithubUrl] = useState("");

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch user profile
  const { data: profile = {}, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (profile && typeof profile === 'object') {
      setLinkedinUrl((profile as any).linkedinUrl || "");
      setGithubUrl((profile as any).githubUrl || "");
    }
  }, [profile]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-secondary">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <div className="flex-1 lg:ml-0">
        <Header />
        
        <main className="p-4 lg:p-6 space-y-8 pb-20 lg:pb-8">
          {/* Header */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-teal-500 rounded-xl flex items-center justify-center">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Personal Branding & Networking</h1>
          </div>

          {/* LinkedIn Optimizer Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Linkedin className="w-5 h-5 text-blue-600" />
                </div>
                <span>LinkedIn Profile Optimizer</span>
                <Badge variant="secondary">AI Analysis</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-secondary">
                Analyze your LinkedIn profile and get personalized suggestions to improve visibility and engagement.
              </p>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="linkedin-url">LinkedIn Profile URL</Label>
                  <Input
                    id="linkedin-url"
                    placeholder="https://linkedin.com/in/yourprofile"
                    value={linkedinUrl}
                    onChange={(e) => setLinkedinUrl(e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                <div className="flex items-center space-x-4">
                  <Button className="bg-primary hover:bg-primary/90">
                    Analyze Profile
                  </Button>
                  {linkedinUrl && (
                    <Button variant="outline" size="sm" asChild>
                      <a href={linkedinUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        View Profile
                      </a>
                    </Button>
                  )}
                </div>
              </div>

              {/* Sample Analysis Results */}
              <div className="mt-6 p-4 bg-muted rounded-lg">
                <h4 className="font-medium text-foreground mb-3 flex items-center">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Profile Analysis
                </h4>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600 mb-1">85%</div>
                    <div className="text-secondary">Profile Completeness</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600 mb-1">7.2</div>
                    <div className="text-secondary">Keyword Score</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600 mb-1">92%</div>
                    <div className="text-secondary">Industry Alignment</div>
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="space-y-3">
                <h4 className="font-medium text-foreground">Recommendations</h4>
                <div className="space-y-2">
                  <div className="flex items-start space-x-3 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                    <p className="text-sm text-foreground">Add more industry-specific keywords to your headline</p>
                  </div>
                  <div className="flex items-start space-x-3 p-3 bg-green-50 dark:bg-green-950/20 rounded-lg">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                    <p className="text-sm text-foreground">Include quantifiable achievements in your experience section</p>
                  </div>
                  <div className="flex items-start space-x-3 p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg">
                    <div className="w-2 h-2 bg-yellow-600 rounded-full mt-2"></div>
                    <p className="text-sm text-foreground">Upload a professional headshot to increase profile views</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* GitHub Analyzer Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                  <Github className="w-5 h-5 text-gray-600" />
                </div>
                <span>GitHub Profile Analyzer</span>
                <Badge variant="secondary">Code Insights</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-secondary">
                Analyze your GitHub activity, repository insights, and get suggestions for better visibility.
              </p>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="github-url">GitHub Profile URL</Label>
                  <Input
                    id="github-url"
                    placeholder="https://github.com/yourusername"
                    value={githubUrl}
                    onChange={(e) => setGithubUrl(e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                <div className="flex items-center space-x-4">
                  <Button className="bg-primary hover:bg-primary/90">
                    Analyze GitHub
                  </Button>
                  {githubUrl && (
                    <Button variant="outline" size="sm" asChild>
                      <a href={githubUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        View Profile
                      </a>
                    </Button>
                  )}
                </div>
              </div>

              {/* GitHub Stats */}
              <div className="mt-6 grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium text-foreground mb-3">Repository Stats</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-secondary">Total Repos:</span>
                      <span className="font-medium">24</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-secondary">Stars Received:</span>
                      <span className="font-medium">156</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-secondary">Forks:</span>
                      <span className="font-medium">42</span>
                    </div>
                  </div>
                </div>
                
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium text-foreground mb-3">Activity Insights</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-secondary">Commits (30d):</span>
                      <span className="font-medium">78</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-secondary">Active Days:</span>
                      <span className="font-medium">23/30</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-secondary">Top Language:</span>
                      <span className="font-medium">TypeScript</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* GitHub README Generator */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Github className="w-5 h-5 text-purple-600" />
                </div>
                <span>GitHub README Generator</span>
                <Badge variant="secondary">Templates</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Create professional README files for your repositories with our template-based generator.
              </p>
              
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center p-6 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <Github className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                  <h4 className="font-medium text-foreground mb-2">Project README</h4>
                  <p className="text-sm text-secondary">Standard project documentation</p>
                </div>
                <div className="text-center p-6 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <Github className="w-8 h-8 text-green-600 mx-auto mb-3" />
                  <h4 className="font-medium text-foreground mb-2">Profile README</h4>
                  <p className="text-sm text-secondary">Personal profile showcase</p>
                </div>
                <div className="text-center p-6 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <Github className="w-8 h-8 text-purple-600 mx-auto mb-3" />
                  <h4 className="font-medium text-foreground mb-2">API Documentation</h4>
                  <p className="text-sm text-secondary">Technical API guides</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Public Portfolio Generator */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <Globe className="w-5 h-5 text-indigo-600" />
                </div>
                <span>Public Portfolio Generator</span>
                <Badge variant="secondary">Clean Templates</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Generate a beautiful public portfolio website to showcase your work and achievements.
              </p>
              
              <div className="p-6 border border-border rounded-lg text-center">
                <Globe className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
                <h4 className="font-medium text-foreground mb-2">Create Your Portfolio</h4>
                <p className="text-sm text-secondary mb-4">Transform your resume and projects into a stunning portfolio</p>
                <Button className="bg-primary hover:bg-primary/90">
                  Generate Portfolio
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Referral Tracker Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Share2 className="w-5 h-5 text-purple-600" />
                </div>
                <span>Referral Tracker</span>
                <Badge variant="secondary">Earn Rewards</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Invite friends to Gradify and earn badges and rewards for successful referrals.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                  <div>
                    <h4 className="font-medium text-foreground">Your Referral Code</h4>
                    <code className="text-sm text-primary font-mono">GRAD-2024-USER123</code>
                  </div>
                  <Button variant="outline" size="sm">
                    Copy Link
                  </Button>
                </div>
                
                <div className="grid md:grid-cols-3 gap-4 text-center">
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-green-600 mb-1">5</div>
                    <div className="text-sm text-secondary">Friends Invited</div>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-blue-600 mb-1">3</div>
                    <div className="text-sm text-secondary">Successfully Joined</div>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-purple-600 mb-1">2</div>
                    <div className="text-sm text-secondary">Badges Earned</div>
                  </div>
                </div>

                <Button className="w-full bg-primary hover:bg-primary/90">
                  <Share2 className="w-4 h-4 mr-2" />
                  Invite More Friends
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
