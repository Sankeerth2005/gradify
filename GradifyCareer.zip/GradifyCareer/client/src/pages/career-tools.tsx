import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Brain, FileText, Mail, Target, Route, UserCheck, Layout, Plus } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function CareerTools() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch data
  const { data: resumes = [], isLoading: resumesLoading } = useQuery({
    queryKey: ["/api/resumes"],
    enabled: isAuthenticated,
  });

  const { data: coverLetters = [], isLoading: coverLettersLoading } = useQuery({
    queryKey: ["/api/cover-letters"],
    enabled: isAuthenticated,
  });

  const { data: roadmaps = [], isLoading: roadmapsLoading } = useQuery({
    queryKey: ["/api/roadmaps"],
    enabled: isAuthenticated,
  });

  const { data: interviewSessions = [], isLoading: interviewSessionsLoading } = useQuery({
    queryKey: ["/api/interview-sessions"],
    enabled: isAuthenticated,
  });

  // Create resume mutation
  const createResumeMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/resumes", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Success",
        description: "Resume created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create resume. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create cover letter mutation
  const createCoverLetterMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/cover-letters", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cover-letters"] });
      toast({
        title: "Success",
        description: "Cover letter created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create cover letter. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create roadmap mutation
  const createRoadmapMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/roadmaps", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roadmaps"] });
      toast({
        title: "Success",
        description: "Career roadmap created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create roadmap. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create interview session mutation
  const createInterviewSessionMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/interview-sessions", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/interview-sessions"] });
      toast({
        title: "Success",
        description: "Interview session created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create interview session. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateResume = () => {
    createResumeMutation.mutate({
      title: "New Resume",
      content: {
        template: "modern",
        sections: {
          personal: {},
          experience: [],
          education: [],
          skills: []
        }
      },
      templateId: "modern",
      isActive: true
    });
  };

  const handleCreateCoverLetter = () => {
    createCoverLetterMutation.mutate({
      title: "New Cover Letter",
      content: "Dear Hiring Manager,\n\nI am writing to express my interest in the position...",
      jobTitle: "",
      companyName: ""
    });
  };

  const handleCreateRoadmap = () => {
    createRoadmapMutation.mutate({
      targetRole: "Software Engineer",
      targetCompany: "",
      steps: [
        { id: 1, title: "Learn Programming Fundamentals", completed: false },
        { id: 2, title: "Build Portfolio Projects", completed: false },
        { id: 3, title: "Practice Data Structures & Algorithms", completed: false },
        { id: 4, title: "Apply to Companies", completed: false }
      ],
      currentStep: 0,
      completed: false
    });
  };

  const handleCreateInterviewSession = () => {
    createInterviewSessionMutation.mutate({
      sessionType: "dsa",
      questions: [
        { id: 1, question: "Two Sum", difficulty: "Easy" },
        { id: 2, question: "Valid Parentheses", difficulty: "Easy" }
      ],
      answers: {},
      score: 0,
      duration: 60,
      completed: false
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-secondary">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <div className="flex-1 lg:ml-0">
        <Header />
        
        <main className="p-4 lg:p-6 space-y-8 pb-20 lg:pb-8">
          {/* Header */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 gradient-primary-accent rounded-xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Career Tools</h1>
          </div>

          {/* Resume Builder Section */}
          <Card className="clean-card border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                  <FileText className="w-6 h-6 text-blue-600" />
                </div>
                <span className="text-xl font-bold text-gray-900">Resume Builder</span>
                <Badge variant="secondary" className="ml-auto">ATS-Ready</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Create professional, ATS-optimized resumes with our intelligent builder.
              </p>
              <div className="flex items-center justify-between mb-4">
                <div className="text-sm text-gray-500 font-medium">
                  {resumesLoading ? "Loading..." : `${Array.isArray(resumes) ? resumes.length : 0} resumes created`}
                </div>
                <Button 
                  onClick={handleCreateResume}
                  disabled={createResumeMutation.isPending}
                  className="btn-primary"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {createResumeMutation.isPending ? "Creating..." : "New Resume"}
                </Button>
              </div>
              {Array.isArray(resumes) && resumes.length > 0 && (
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">Recent Resumes</h4>
                  {resumes.slice(0, 3).map((resume: any) => (
                    <div key={resume.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                        <p className="font-semibold text-gray-900">{resume.title}</p>
                        <p className="text-sm text-gray-500 mt-1">
                          {resume.atsScore ? `ATS Score: ${resume.atsScore}/100` : "Not scored yet"}
                        </p>
                      </div>
                      <Badge variant={resume.isActive ? "default" : "outline"}>
                        {resume.isActive ? "Active" : "Draft"}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Cover Letter Generator Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Mail className="w-5 h-5 text-purple-600" />
                </div>
                <span>Cover Letter Generator</span>
                <Badge variant="secondary">AI-Powered</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Generate personalized cover letters tailored to specific job requirements.
              </p>
              <div className="flex items-center justify-between">
                <div className="text-sm text-secondary">
                  {coverLettersLoading ? "Loading..." : `${Array.isArray(coverLetters) ? coverLetters.length : 0} cover letters created`}
                </div>
                <Button 
                  onClick={handleCreateCoverLetter}
                  disabled={createCoverLetterMutation.isPending}
                  className="bg-primary hover:bg-primary/90"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {createCoverLetterMutation.isPending ? "Creating..." : "New Cover Letter"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* ATS Score Checker Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Target className="w-5 h-5 text-yellow-600" />
                </div>
                <span>ATS Score Checker</span>
                <Badge variant="secondary">Popular</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Upload your resume to get detailed ATS compatibility scores and improvement suggestions.
              </p>
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-secondary mb-4">Drag and drop your resume here or click to browse</p>
                <Button variant="outline">Choose File</Button>
              </div>
            </CardContent>
          </Card>

          {/* Career Roadmap Generator Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <Route className="w-5 h-5 text-green-600" />
                </div>
                <span>Career Roadmap Generator</span>
                <Badge variant="secondary">Trending</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Create step-by-step career paths to reach your dream job with AI-powered recommendations.
              </p>
              <div className="flex items-center justify-between">
                <div className="text-sm text-secondary">
                  {roadmapsLoading ? "Loading..." : `${Array.isArray(roadmaps) ? roadmaps.length : 0} roadmaps created`}
                </div>
                <Button 
                  onClick={handleCreateRoadmap}
                  disabled={createRoadmapMutation.isPending}
                  className="bg-primary hover:bg-primary/90"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {createRoadmapMutation.isPending ? "Creating..." : "New Roadmap"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Interview Prep Tracker Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                  <UserCheck className="w-5 h-5 text-red-600" />
                </div>
                <span>Interview Prep Tracker</span>
                <Badge variant="secondary">Essential</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Track your progress on data structures, algorithms, and mock interview sessions.
              </p>
              <div className="flex items-center justify-between">
                <div className="text-sm text-secondary">
                  {interviewSessionsLoading ? "Loading..." : `${Array.isArray(interviewSessions) ? interviewSessions.length : 0} sessions completed`}
                </div>
                <Button 
                  onClick={handleCreateInterviewSession}
                  disabled={createInterviewSessionMutation.isPending}
                  className="bg-primary hover:bg-primary/90"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {createInterviewSessionMutation.isPending ? "Creating..." : "New Session"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Portfolio Generator Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <Layout className="w-5 h-5 text-indigo-600" />
                </div>
                <span>Portfolio Generator</span>
                <Badge variant="secondary">Pro</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Convert your resume into a beautiful portfolio website with one click.
              </p>
              <div className="text-center p-8 bg-muted rounded-lg">
                <Layout className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-secondary mb-4">Transform your resume into a stunning portfolio</p>
                <Button variant="outline">Generate Portfolio</Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
