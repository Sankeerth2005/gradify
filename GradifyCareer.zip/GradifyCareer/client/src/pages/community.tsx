import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Users, Video, Timer, CheckCircle, Trophy, Award, Plus, Play, Pause, RotateCcw } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Community() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  
  // Pomodoro timer state
  const [pomodoroTime, setPomodoroTime] = useState(25 * 60); // 25 minutes
  const [isRunning, setIsRunning] = useState(false);
  const [pomodoroMode, setPomodoroMode] = useState<'work' | 'break'>('work');
  
  // Task creation state
  const [newTask, setNewTask] = useState({ title: '', description: '', category: 'study' });
  
  // Study room creation state
  const [newRoom, setNewRoom] = useState({ name: '', description: '', topic: '', maxParticipants: 10 });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Pomodoro timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && pomodoroTime > 0) {
      interval = setInterval(() => {
        setPomodoroTime(time => time - 1);
      }, 1000);
    } else if (pomodoroTime === 0) {
      setIsRunning(false);
      toast({
        title: `${pomodoroMode === 'work' ? 'Work' : 'Break'} session complete!`,
        description: `Time to ${pomodoroMode === 'work' ? 'take a break' : 'get back to work'}`,
      });
      setPomodoroMode(prev => prev === 'work' ? 'break' : 'work');
      setPomodoroTime(pomodoroMode === 'work' ? 5 * 60 : 25 * 60);
    }
    return () => clearInterval(interval);
  }, [isRunning, pomodoroTime, pomodoroMode, toast]);

  // Fetch data
  const { data: studyRooms = [], isLoading: studyRoomsLoading } = useQuery({
    queryKey: ["/api/study-rooms"],
    enabled: isAuthenticated,
  });

  const { data: myRooms = [] } = useQuery({
    queryKey: ["/api/study-rooms/my"],
    enabled: isAuthenticated,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ["/api/tasks"],
    enabled: isAuthenticated,
  });

  const { data: badges = [] } = useQuery({
    queryKey: ["/api/badges"],
    enabled: isAuthenticated,
  });

  // Create study room mutation
  const createRoomMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/study-rooms", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/study-rooms"] });
      setNewRoom({ name: '', description: '', topic: '', maxParticipants: 10 });
      toast({
        title: "Success",
        description: "Study room created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create study room. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/tasks", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setNewTask({ title: '', description: '', category: 'study' });
      toast({
        title: "Success",
        description: "Task created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create task. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Join study room mutation
  const joinRoomMutation = useMutation({
    mutationFn: async (roomId: string) => {
      const response = await apiRequest("POST", `/api/study-rooms/${roomId}/join`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/study-rooms"] });
      queryClient.invalidateQueries({ queryKey: ["/api/study-rooms/my"] });
      toast({
        title: "Success",
        description: "Joined study room successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized", 
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to join study room. Please try again.",
        variant: "destructive",
      });
    },
  });

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCreateRoom = () => {
    if (!newRoom.name || !newRoom.topic) {
      toast({
        title: "Error",
        description: "Please fill in room name and topic.",
        variant: "destructive",
      });
      return;
    }
    createRoomMutation.mutate(newRoom);
  };

  const handleCreateTask = () => {
    if (!newTask.title) {
      toast({
        title: "Error",
        description: "Please enter a task title.",
        variant: "destructive",
      });
      return;
    }
    createTaskMutation.mutate(newTask);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-secondary">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <div className="flex-1 lg:ml-0">
        <Header />
        
        <main className="p-4 lg:p-6 space-y-8 pb-20 lg:pb-8">
          {/* Header */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Community Module</h1>
          </div>

          {/* Study Rooms Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <Video className="w-5 h-5 text-indigo-600" />
                  </div>
                  <span>Virtual Study Rooms</span>
                  <Badge variant="secondary">Collaborative</Badge>
                </div>
                <Button 
                  size="sm" 
                  onClick={() => {
                    const modal = document.getElementById('create-room-modal');
                    if (modal) modal.style.display = 'block';
                  }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Room
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Join topic-based study rooms to collaborate with peers and stay motivated.
              </p>
              
              {studyRoomsLoading ? (
                <div className="text-center py-8">
                  <div className="w-6 h-6 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                  <p className="text-secondary">Loading study rooms...</p>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Array.isArray(studyRooms) ? studyRooms.map((room: any) => (
                    <div key={room.id} className="p-4 border border-border rounded-lg hover:bg-muted transition-colors">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium text-foreground">{room.name}</h4>
                        <Badge variant="outline">{room.topic}</Badge>
                      </div>
                      <p className="text-sm text-secondary mb-3">{room.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-secondary">
                          {room.currentParticipants}/{room.maxParticipants} participants
                        </span>
                        <Button 
                          size="sm" 
                          onClick={() => joinRoomMutation.mutate(room.id)}
                          disabled={joinRoomMutation.isPending}
                        >
                          {joinRoomMutation.isPending ? "Joining..." : "Join"}
                        </Button>
                      </div>
                    </div>
                  )) : (
                    <div className="col-span-full text-center py-8">
                      <Video className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-secondary">No study rooms available. Create one to get started!</p>
                    </div>
                  )}
                </div>
              )}

              {/* My Rooms */}
              {Array.isArray(myRooms) && myRooms.length > 0 && (
                <div className="mt-6">
                  <h4 className="font-medium text-foreground mb-3">My Study Rooms</h4>
                  <div className="space-y-2">
                    {myRooms.map((room: any) => (
                      <div key={room.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div>
                          <p className="font-medium text-foreground">{room.name}</p>
                          <p className="text-sm text-secondary">{room.topic}</p>
                        </div>
                        <Button variant="outline" size="sm">
                          Enter Room
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Pomodoro Timer Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                  <Timer className="w-5 h-5 text-red-600" />
                </div>
                <span>Pomodoro Timer</span>
                <Badge variant="secondary">{pomodoroMode === 'work' ? 'Work Mode' : 'Break Mode'}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-6">
                <div className="text-6xl font-bold text-foreground">
                  {formatTime(pomodoroTime)}
                </div>
                
                <div className="flex items-center justify-center space-x-4">
                  <Button
                    onClick={() => setIsRunning(!isRunning)}
                    className="bg-primary hover:bg-primary/90"
                  >
                    {isRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                    {isRunning ? 'Pause' : 'Start'}
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsRunning(false);
                      setPomodoroTime(pomodoroMode === 'work' ? 25 * 60 : 5 * 60);
                    }}
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Reset
                  </Button>
                </div>
                
                <p className="text-secondary">
                  {pomodoroMode === 'work' 
                    ? 'Stay focused and productive during your work session'
                    : 'Take a well-deserved break to recharge'
                  }
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Task Tracker Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <span>Task Tracker & Milestones</span>
                </div>
                <Button 
                  size="sm" 
                  onClick={() => {
                    const modal = document.getElementById('create-task-modal');
                    if (modal) modal.style.display = 'block';
                  }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Task
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Track your daily goals and celebrate milestone achievements.
              </p>
              
              {Array.isArray(tasks) && tasks.length > 0 ? (
                <div className="space-y-3">
                  {tasks.slice(0, 5).map((task: any) => (
                    <div key={task.id} className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                      <CheckCircle className={`w-5 h-5 ${task.status === 'completed' ? 'text-green-600' : 'text-gray-400'}`} />
                      <div className="flex-1">
                        <p className={`font-medium ${task.status === 'completed' ? 'line-through text-secondary' : 'text-foreground'}`}>
                          {task.title}
                        </p>
                        <p className="text-xs text-secondary">{task.category}</p>
                      </div>
                      <Badge variant={task.status === 'completed' ? 'default' : 'outline'}>
                        {task.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-secondary">No tasks yet. Add your first task to get started!</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Leaderboard Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Trophy className="w-5 h-5 text-yellow-600" />
                </div>
                <span>Weekly Leaderboard</span>
                <Badge variant="secondary">XP-Based</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                See how you rank against other community members this week.
              </p>
              
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((rank) => (
                  <div key={rank} className="flex items-center space-x-4 p-3 bg-muted rounded-lg">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                      rank === 1 ? 'bg-yellow-500' : rank === 2 ? 'bg-gray-400' : rank === 3 ? 'bg-orange-600' : 'bg-gray-600'
                    }`}>
                      {rank}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">User {rank}</p>
                      <p className="text-xs text-secondary">{1500 - rank * 100} XP this week</p>
                    </div>
                    {rank <= 3 && (
                      <Trophy className={`w-5 h-5 ${rank === 1 ? 'text-yellow-500' : rank === 2 ? 'text-gray-400' : 'text-orange-600'}`} />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Badge Showcase Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-pink-100 rounded-lg flex items-center justify-center">
                  <Award className="w-5 h-5 text-pink-600" />
                </div>
                <span>Badge Showcase</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Display your achievements and see how to earn new badges.
              </p>
              
              {Array.isArray(badges) && badges.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {badges.map((badge: any) => (
                    <div key={badge.id} className="text-center p-4 border border-border rounded-lg">
                      <Award className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                      <h4 className="font-medium text-foreground text-sm">{badge.badgeName}</h4>
                      <p className="text-xs text-secondary mt-1">{badge.description}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Award className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-secondary">No badges earned yet. Complete tasks and milestones to earn your first badge!</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Create Room Modal */}
          <div id="create-room-modal" className="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <Card className="w-full max-w-md mx-4">
              <CardHeader>
                <CardTitle>Create Study Room</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="room-name">Room Name</Label>
                  <Input
                    id="room-name"
                    value={newRoom.name}
                    onChange={(e) => setNewRoom(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter room name"
                  />
                </div>
                <div>
                  <Label htmlFor="room-topic">Topic</Label>
                  <Input
                    id="room-topic"
                    value={newRoom.topic}
                    onChange={(e) => setNewRoom(prev => ({ ...prev, topic: e.target.value }))}
                    placeholder="e.g., Data Structures, Machine Learning"
                  />
                </div>
                <div>
                  <Label htmlFor="room-description">Description</Label>
                  <Textarea
                    id="room-description"
                    value={newRoom.description}
                    onChange={(e) => setNewRoom(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of the study room"
                  />
                </div>
                <div className="flex space-x-2">
                  <Button 
                    onClick={handleCreateRoom}
                    disabled={createRoomMutation.isPending}
                    className="flex-1"
                  >
                    {createRoomMutation.isPending ? "Creating..." : "Create Room"}
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => {
                      const modal = document.getElementById('create-room-modal');
                      if (modal) modal.style.display = 'none';
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Create Task Modal */}
          <div id="create-task-modal" className="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <Card className="w-full max-w-md mx-4">
              <CardHeader>
                <CardTitle>Add New Task</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="task-title">Task Title</Label>
                  <Input
                    id="task-title"
                    value={newTask.title}
                    onChange={(e) => setNewTask(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Enter task title"
                  />
                </div>
                <div>
                  <Label htmlFor="task-description">Description</Label>
                  <Textarea
                    id="task-description"
                    value={newTask.description}
                    onChange={(e) => setNewTask(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Task description (optional)"
                  />
                </div>
                <div className="flex space-x-2">
                  <Button 
                    onClick={handleCreateTask}
                    disabled={createTaskMutation.isPending}
                    className="flex-1"
                  >
                    {createTaskMutation.isPending ? "Creating..." : "Add Task"}
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => {
                      const modal = document.getElementById('create-task-modal');
                      if (modal) modal.style.display = 'none';
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
