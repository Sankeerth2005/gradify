import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import WelcomeSection from "@/components/dashboard/welcome-section";
import { ToolCard } from "@/components/dashboard/tool-card";
import ActivityFeed from "@/components/dashboard/activity-feed";
import { Brain, Microscope, Globe, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch dashboard data
  const { data: resumes = [] } = useQuery({
    queryKey: ["/api/resumes"],
    enabled: isAuthenticated,
  });

  const { data: badges = [] } = useQuery({
    queryKey: ["/api/badges"],
    enabled: isAuthenticated,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ["/api/tasks"],
    enabled: isAuthenticated,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-secondary">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const careerTools = [
    {
      icon: "FileText",
      iconColor: "blue",
      title: "Resume Builder",
      description: "Create ATS-ready resumes with professional templates",
      badge: "New Templates",
      badgeColor: "green",
      href: "/career-tools"
    },
    {
      icon: "Mail",
      iconColor: "purple",
      title: "Cover Letter Generator",
      description: "Job-specific cover letters with AI assistance",
      badge: "AI Powered",
      badgeColor: "blue",
      href: "/career-tools"
    },
    {
      icon: "Target",
      iconColor: "yellow",
      title: "ATS Score Checker",
      description: "Upload and get detailed score reports",
      badge: "Popular",
      badgeColor: "orange",
      href: "/career-tools"
    },
    {
      icon: "Route",
      iconColor: "green",
      title: "Career Roadmap",
      description: "Step-by-step path to your dream job",
      badge: "Trending",
      badgeColor: "purple",
      href: "/career-tools"
    },
    {
      icon: "UserCheck",
      iconColor: "red",
      title: "Interview Prep",
      description: "DSA progress and mock interview tracking",
      badge: "Essential",
      badgeColor: "red",
      href: "/career-tools"
    },
    {
      icon: "Layout",
      iconColor: "indigo",
      title: "Portfolio Generator",
      description: "One-click resume to portfolio conversion",
      badge: "Pro",
      badgeColor: "indigo",
      href: "/career-tools"
    }
  ];

  const researchTools = [
    {
      icon: "ShieldCheck",
      iconColor: "red",
      title: "Plagiarism Checker",
      description: "Upload and scan documents",
      href: "/research"
    },
    {
      icon: "User",
      iconColor: "blue",
      title: "AI Humanizer",
      description: "Make content sound natural",
      href: "/research"
    },
    {
      icon: "FileEdit",
      iconColor: "green",
      title: "Paper Writer",
      description: "Generate research content",
      href: "/research"
    },
    {
      icon: "Quote",
      iconColor: "yellow",
      title: "Citation Generator",
      description: "APA, MLA, BibTeX formats",
      href: "/research"
    }
  ];

  const brandingTools = [
    {
      icon: "Linkedin",
      iconColor: "blue",
      title: "LinkedIn Optimizer",
      description: "Analyze and improve your profile",
      href: "/branding"
    },
    {
      icon: "Github",
      iconColor: "gray",
      title: "GitHub Analyzer",
      description: "Code activity and repo insights",
      href: "/branding"
    },
    {
      icon: "Share2",
      iconColor: "purple",
      title: "Referral Tracker",
      description: "Invite friends and earn rewards",
      href: "/branding"
    }
  ];

  const communityTools = [
    {
      icon: "Video",
      iconColor: "indigo",
      title: "Study Rooms",
      description: "Virtual collaboration spaces",
      href: "/community"
    },
    {
      icon: "Timer",
      iconColor: "red",
      title: "Pomodoro Timer",
      description: "Focus mode with sounds",
      href: "/community"
    },
    {
      icon: "CheckCircle",
      iconColor: "green",
      title: "Task Tracker",
      description: "Daily goals & milestones",
      href: "/community"
    },
    {
      icon: "Trophy",
      iconColor: "yellow",
      title: "Leaderboard",
      description: "Weekly top contributors",
      href: "/community"
    },
    {
      icon: "Award",
      iconColor: "pink",
      title: "Badge Showcase",
      description: "Your achievements",
      href: "/community"
    }
  ];

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <div className="flex-1 lg:ml-0">
        <Header />
        
        <main className="p-4 lg:p-6 space-y-8 pb-20 lg:pb-8">
          <WelcomeSection 
            resumeCount={Array.isArray(resumes) ? resumes.length : 0}
            badgeCount={Array.isArray(badges) ? badges.length : 0}
            taskCount={Array.isArray(tasks) ? tasks.filter((task: any) => task.status === 'completed').length : 0}
          />

          {/* Career Tools Section */}
          <section>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 gradient-primary-accent rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-foreground">Career Tools</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {careerTools.map((tool, index) => (
                <ToolCard key={index} {...tool} />
              ))}
            </div>
          </section>

          {/* Research Utilities Section */}
          <section>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                <Microscope className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-foreground">Research Utilities</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {researchTools.map((tool, index) => (
                <ToolCard key={index} {...tool} />
              ))}
            </div>
          </section>

          {/* Personal Branding Section */}
          <section>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-teal-500 rounded-xl flex items-center justify-center">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-foreground">Personal Branding & Networking</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {brandingTools.map((tool, index) => (
                <ToolCard key={index} {...tool} />
              ))}
            </div>
          </section>

          {/* Community Section */}
          <section>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-foreground">Community Module</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
              {communityTools.map((tool, index) => (
                <ToolCard key={index} {...tool} />
              ))}
            </div>
          </section>

          <ActivityFeed />
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
