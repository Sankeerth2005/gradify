import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, Brain, Microscope, Globe, Users, ArrowRight } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen gradient-bg">
      {/* Hero Section */}
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Panel - Content */}
          <div className="text-center lg:text-left space-y-8">
            <div className="flex items-center justify-center lg:justify-start space-x-4 mb-8">
              <div className="w-14 h-14 gradient-primary rounded-2xl flex items-center justify-center shadow-lg">
                <GraduationCap className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900">Gradify</h1>
            </div>
            
            <div>
              <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
                Your Career, Curated.
              </h2>
              
              <p className="text-xl text-gray-600 mb-8 max-w-2xl leading-relaxed">
                Transform your career with AI-powered tools, expert guidance, and a supportive community. 
                Build better resumes, ace interviews, and unlock your potential.
              </p>
            </div>

            <div className="space-y-4 mb-10">
              <div className="flex items-center justify-center lg:justify-start space-x-4">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center shadow-sm">
                  <span className="text-white text-sm font-medium">✓</span>
                </div>
                <span className="text-lg text-gray-700 font-medium">ATS-ready resume builder</span>
              </div>
              <div className="flex items-center justify-center lg:justify-start space-x-4">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center shadow-sm">
                  <span className="text-white text-sm font-medium">✓</span>
                </div>
                <span className="text-lg text-gray-700 font-medium">AI-powered interview prep</span>
              </div>
              <div className="flex items-center justify-center lg:justify-start space-x-4">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center shadow-sm">
                  <span className="text-white text-sm font-medium">✓</span>
                </div>
                <span className="text-lg text-gray-700 font-medium">Virtual study communities</span>
              </div>
            </div>

            <Button 
              size="lg" 
              className="btn-primary text-lg px-10 py-4"
              onClick={() => window.location.href = '/api/login'}
            >
              Get Started Free
              <ArrowRight className="ml-3 w-6 h-6" />
            </Button>
          </div>

          {/* Right Panel - Features Preview */}
          <div className="space-y-6">
            <Card className="clean-card p-6 border-0">
              <CardContent className="p-0">
                <div className="flex items-center space-x-5">
                  <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center">
                    <Brain className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Career Tools</h3>
                    <p className="text-gray-600">Resume builder, cover letters, career roadmaps</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="clean-card p-6 border-0">
              <CardContent className="p-0">
                <div className="flex items-center space-x-5">
                  <div className="w-16 h-16 bg-purple-50 rounded-2xl flex items-center justify-center">
                    <Microscope className="w-8 h-8 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Research Tools</h3>
                    <p className="text-gray-600">Plagiarism checker, AI humanizer tools</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="clean-card p-6 border-0">
              <CardContent className="p-0">
                <div className="flex items-center space-x-5">
                  <div className="w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center">
                    <Globe className="w-8 h-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Personal Branding</h3>
                    <p className="text-gray-600">LinkedIn optimizer, GitHub analyzer</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="clean-card p-6 border-0">
              <CardContent className="p-0">
                <div className="flex items-center space-x-5">
                  <div className="w-16 h-16 bg-orange-50 rounded-2xl flex items-center justify-center">
                    <Users className="w-8 h-8 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Community</h3>
                    <p className="text-gray-600">Study rooms, task tracking, achievements</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Everything you need to advance your career
            </h2>
            <p className="text-lg text-secondary max-w-2xl mx-auto">
              From resume building to interview preparation, our comprehensive platform provides 
              all the tools you need for career success.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 gradient-primary-accent rounded-2xl flex items-center justify-center mx-auto mb-4 neumorphic">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">AI-Powered Tools</h3>
              <p className="text-sm text-secondary">Smart assistance for resumes, cover letters, and career planning</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 gradient-primary-accent rounded-2xl flex items-center justify-center mx-auto mb-4 neumorphic">
                <Microscope className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Research Support</h3>
              <p className="text-sm text-secondary">Academic writing tools with plagiarism checking and citations</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 gradient-primary-accent rounded-2xl flex items-center justify-center mx-auto mb-4 neumorphic">
                <Globe className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Professional Branding</h3>
              <p className="text-sm text-secondary">Optimize your online presence across all platforms</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 gradient-primary-accent rounded-2xl flex items-center justify-center mx-auto mb-4 neumorphic">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Study Community</h3>
              <p className="text-sm text-secondary">Connect with peers in virtual study rooms and tracking</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 gradient-mint-beige">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Ready to take your career to the next level?
          </h2>
          <p className="text-lg text-secondary mb-8">
            Join thousands of students and professionals already using Gradify to achieve their career goals.
          </p>
          <Button 
            size="lg" 
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-8 py-3 rounded-2xl neumorphic neumorphic-hover"
            onClick={() => window.location.href = '/api/login'}
          >
            Start Your Journey
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>
    </div>
  );
}
