import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { User, Upload, Save, Settings, Award, FileText } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Profile() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  
  const [profileData, setProfileData] = useState({
    skills: [] as string[],
    education: {},
    careerGoals: '',
    experience: {},
    linkedinUrl: '',
    githubUrl: ''
  });
  
  const [skillInput, setSkillInput] = useState('');

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch user profile
  const { data: profile = {}, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
  });

  // Fetch user badges
  const { data: badges = [] } = useQuery({
    queryKey: ["/api/badges"],
    enabled: isAuthenticated,
  });

  // Fetch user resumes
  const { data: resumes = [] } = useQuery({
    queryKey: ["/api/resumes"],
    enabled: isAuthenticated,
  });

  // Update profile whenever data changes
  useEffect(() => {
    if (profile && typeof profile === 'object') {
      const p = profile as any;
      setProfileData({
        skills: p.skills || [],
        education: p.education || {},
        careerGoals: p.careerGoals || '',
        experience: p.experience || {},
        linkedinUrl: p.linkedinUrl || '',
        githubUrl: p.githubUrl || ''
      });
    }
  }, [profile]);

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/profile", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      toast({
        title: "Success",
        description: "Profile updated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSaveProfile = () => {
    updateProfileMutation.mutate(profileData);
  };

  const addSkill = () => {
    if (skillInput.trim() && !profileData.skills.includes(skillInput.trim())) {
      setProfileData(prev => ({
        ...prev,
        skills: [...prev.skills, skillInput.trim()]
      }));
      setSkillInput('');
    }
  };

  const removeSkill = (skillToRemove: string) => {
    setProfileData(prev => ({
      ...prev,
      skills: prev.skills.filter(skill => skill !== skillToRemove)
    }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-secondary">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <div className="flex-1 lg:ml-0">
        <Header />
        
        <main className="p-4 lg:p-6 space-y-8 pb-20 lg:pb-8">
          {/* Header */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Profile Settings</h1>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Profile Overview */}
            <div className="lg:col-span-1 space-y-6">
              {/* Profile Card */}
              <Card className="neumorphic border-0">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3">
                    <Settings className="w-5 h-5" />
                    <span>Profile Overview</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <Avatar className="w-24 h-24 mx-auto mb-4">
                    <AvatarImage src={(user as any)?.profileImageUrl} />
                    <AvatarFallback className="text-xl">
                      {(user as any)?.firstName?.[0] || (user as any)?.email?.[0] || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  
                  <h3 className="text-xl font-semibold text-foreground mb-1">
                    {(user as any)?.firstName || (user as any)?.lastName 
                      ? `${(user as any).firstName || ''} ${(user as any).lastName || ''}`.trim()
                      : 'User'
                    }
                  </h3>
                  <p className="text-secondary mb-4">{(user as any)?.email}</p>
                  
                  <Button variant="outline" className="mb-4">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Photo
                  </Button>
                  
                  <div className="text-left space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-secondary">Member since:</span>
                      <span className="text-foreground">
                        {new Date((user as any)?.createdAt || Date.now()).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-secondary">Resumes:</span>
                      <span className="text-foreground">{Array.isArray(resumes) ? resumes.length : 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-secondary">Badges:</span>
                      <span className="text-foreground">{Array.isArray(badges) ? badges.length : 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Badges */}
              <Card className="neumorphic border-0">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3">
                    <Award className="w-5 h-5" />
                    <span>Your Badges</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {Array.isArray(badges) && badges.length > 0 ? (
                    <div className="grid grid-cols-2 gap-3">
                      {badges.map((badge: any) => (
                        <div key={badge.id} className="text-center p-3 bg-muted rounded-lg">
                          <Award className="w-6 h-6 text-purple-600 mx-auto mb-1" />
                          <p className="text-xs font-medium text-foreground">{badge.badgeName}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <Award className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-secondary">No badges earned yet</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Profile Details */}
            <div className="lg:col-span-2 space-y-6">
              {/* Basic Information */}
              <Card className="neumorphic border-0">
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="linkedin-url">LinkedIn Profile</Label>
                      <Input
                        id="linkedin-url"
                        placeholder="https://linkedin.com/in/yourprofile"
                        value={profileData.linkedinUrl}
                        onChange={(e) => setProfileData(prev => ({ ...prev, linkedinUrl: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="github-url">GitHub Profile</Label>
                      <Input
                        id="github-url"
                        placeholder="https://github.com/yourusername"
                        value={profileData.githubUrl}
                        onChange={(e) => setProfileData(prev => ({ ...prev, githubUrl: e.target.value }))}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="career-goals">Career Goals</Label>
                    <Textarea
                      id="career-goals"
                      placeholder="Describe your career goals and aspirations..."
                      value={profileData.careerGoals}
                      onChange={(e) => setProfileData(prev => ({ ...prev, careerGoals: e.target.value }))}
                      className="mt-1"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Skills */}
              <Card className="neumorphic border-0">
                <CardHeader>
                  <CardTitle>Skills & Expertise</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Add a skill..."
                      value={skillInput}
                      onChange={(e) => setSkillInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addSkill()}
                      className="flex-1"
                    />
                    <Button onClick={addSkill} disabled={!skillInput.trim()}>
                      Add
                    </Button>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {profileData.skills.map((skill, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground"
                        onClick={() => removeSkill(skill)}
                      >
                        {skill} ×
                      </Badge>
                    ))}
                  </div>
                  
                  {profileData.skills.length === 0 && (
                    <p className="text-sm text-secondary">No skills added yet. Add your first skill above!</p>
                  )}
                </CardContent>
              </Card>

              {/* Resume Upload */}
              <Card className="neumorphic border-0">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3">
                    <FileText className="w-5 h-5" />
                    <span>Resume & Documents</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                    <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-secondary mb-4">Upload your latest resume (PDF format)</p>
                    <Button variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Choose File
                    </Button>
                  </div>
                  
                  {Array.isArray(resumes) && resumes.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-medium text-foreground mb-2">Your Resumes</h4>
                      <div className="space-y-2">
                        {resumes.slice(0, 3).map((resume: any) => (
                          <div key={resume.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                            <div className="flex items-center space-x-3">
                              <FileText className="w-4 h-4 text-blue-600" />
                              <span className="text-sm font-medium text-foreground">{resume.title}</span>
                            </div>
                            <Badge variant={resume.isActive ? "default" : "outline"}>
                              {resume.isActive ? "Active" : "Draft"}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Save Button */}
              <div className="flex justify-end">
                <Button 
                  onClick={handleSaveProfile}
                  disabled={updateProfileMutation.isPending}
                  className="bg-primary hover:bg-primary/90"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {updateProfileMutation.isPending ? "Saving..." : "Save Profile"}
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
