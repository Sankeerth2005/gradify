import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Microscope, ShieldCheck, User, FileEdit, Quote, Upload, Plus } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useState } from "react";

export default function Research() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [documentText, setDocumentText] = useState("");

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch research documents
  const { data: documents = [], isLoading: documentsLoading } = useQuery({
    queryKey: ["/api/research-documents"],
    enabled: isAuthenticated,
  });

  // Create research document mutation
  const createDocumentMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/research-documents", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/research-documents"] });
      setDocumentText("");
      toast({
        title: "Success",
        description: "Document uploaded for plagiarism check!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to upload document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePlagiarismCheck = () => {
    if (!documentText.trim()) {
      toast({
        title: "Error",
        description: "Please enter some text to check for plagiarism.",
        variant: "destructive",
      });
      return;
    }

    const wordCount = documentText.trim().split(/\s+/).length;
    
    createDocumentMutation.mutate({
      title: `Plagiarism Check - ${new Date().toLocaleDateString()}`,
      content: documentText,
      wordCount,
      status: 'pending'
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-secondary">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <div className="flex-1 lg:ml-0">
        <Header />
        
        <main className="p-4 lg:p-6 space-y-8 pb-20 lg:pb-8">
          {/* Header */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <Microscope className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Research Utilities</h1>
          </div>

          {/* Plagiarism Checker Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-red-600" />
                </div>
                <span>Plagiarism Checker</span>
                <Badge variant="secondary">1000-2000 words</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-secondary">
                Upload your text or document to check for originality and get detailed plagiarism reports.
              </p>
              
              <div className="space-y-4">
                <Textarea
                  placeholder="Paste your text here (1000-2000 words recommended)..."
                  value={documentText}
                  onChange={(e) => setDocumentText(e.target.value)}
                  className="min-h-[200px] resize-none"
                />
                
                <div className="flex items-center justify-between">
                  <div className="text-sm text-secondary">
                    Words: {documentText.trim() ? documentText.trim().split(/\s+/).length : 0}
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Upload File
                    </Button>
                    <Button 
                      onClick={handlePlagiarismCheck}
                      disabled={createDocumentMutation.isPending || !documentText.trim()}
                      className="bg-primary hover:bg-primary/90"
                    >
                      {createDocumentMutation.isPending ? "Checking..." : "Check Plagiarism"}
                    </Button>
                  </div>
                </div>
              </div>

              {/* Recent checks */}
              {Array.isArray(documents) && documents.length > 0 && (
                <div className="mt-6 space-y-3">
                  <h4 className="font-medium text-foreground">Recent Checks</h4>
                  {documents.slice(0, 3).map((doc: any) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div>
                        <p className="font-medium text-foreground">{doc.title}</p>
                        <p className="text-xs text-secondary">
                          {doc.wordCount} words • {new Date(doc.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        {doc.originalityScore ? (
                          <Badge variant={doc.originalityScore >= 80 ? "default" : "destructive"}>
                            {doc.originalityScore}% Original
                          </Badge>
                        ) : (
                          <Badge variant="outline">Processing</Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* AI Humanizer Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <User className="w-5 h-5 text-blue-600" />
                </div>
                <span>AI Humanizer</span>
                <Badge variant="secondary">Natural Writing</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Transform AI-generated content to sound more natural and human-like.
              </p>
              <div className="space-y-4">
                <Textarea
                  placeholder="Paste your AI-generated text here to humanize it..."
                  className="min-h-[150px] resize-none"
                />
                <div className="flex items-center justify-between">
                  <div className="text-sm text-secondary">
                    AI detection risk: <span className="text-orange-600 font-medium">Medium</span>
                  </div>
                  <Button className="bg-primary hover:bg-primary/90">
                    Humanize Text
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Research Paper Writer Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <FileEdit className="w-5 h-5 text-green-600" />
                </div>
                <span>Research Paper Writer</span>
                <Badge variant="secondary">AI-Assisted</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Generate research paper components including abstracts, introductions, and conclusions.
              </p>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center p-6 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <FileEdit className="w-8 h-8 text-green-600 mx-auto mb-3" />
                  <h4 className="font-medium text-foreground mb-2">Abstract Generator</h4>
                  <p className="text-sm text-secondary">Create compelling research abstracts</p>
                </div>
                <div className="text-center p-6 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <FileEdit className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                  <h4 className="font-medium text-foreground mb-2">Introduction Writer</h4>
                  <p className="text-sm text-secondary">Generate engaging introductions</p>
                </div>
                <div className="text-center p-6 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <FileEdit className="w-8 h-8 text-purple-600 mx-auto mb-3" />
                  <h4 className="font-medium text-foreground mb-2">Conclusion Helper</h4>
                  <p className="text-sm text-secondary">Craft strong conclusions</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Citation Generator Section */}
          <Card className="neumorphic border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Quote className="w-5 h-5 text-yellow-600" />
                </div>
                <span>Citation Generator</span>
                <Badge variant="secondary">Multiple Formats</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-secondary mb-4">
                Generate properly formatted citations in APA, MLA, Chicago, and BibTeX formats.
              </p>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="text-center p-4 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <Quote className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                  <h4 className="font-medium text-foreground text-sm">APA Style</h4>
                </div>
                <div className="text-center p-4 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <Quote className="w-6 h-6 text-green-600 mx-auto mb-2" />
                  <h4 className="font-medium text-foreground text-sm">MLA Style</h4>
                </div>
                <div className="text-center p-4 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <Quote className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                  <h4 className="font-medium text-foreground text-sm">Chicago</h4>
                </div>
                <div className="text-center p-4 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer">
                  <Quote className="w-6 h-6 text-orange-600 mx-auto mb-2" />
                  <h4 className="font-medium text-foreground text-sm">BibTeX</h4>
                </div>
              </div>
              <div className="mt-4">
                <Button className="w-full bg-primary hover:bg-primary/90">
                  <Plus className="w-4 h-4 mr-2" />
                  Create New Citation
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
