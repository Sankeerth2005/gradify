import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { apiRequest } from '@/lib/queryClient';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import Sidebar from '@/components/layout/sidebar';
import Header from '@/components/layout/header';
import MobileNav from '@/components/layout/mobile-nav';
import { Check, Crown, Star, Zap, Shield } from 'lucide-react';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY!);

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  interval: string;
  features: string[];
  description: string;
}

function CheckoutForm({ planId, clientSecret, onSuccess }: { 
  planId: string; 
  clientSecret: string; 
  onSuccess: () => void; 
}) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsLoading(true);

    const { error, paymentIntent } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/subscription?success=true`,
      },
      redirect: 'if_required'
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else if (paymentIntent && paymentIntent.status === 'succeeded') {
      // Confirm subscription on backend
      try {
        await apiRequest('POST', '/api/subscription/confirm', {
          paymentIntentId: paymentIntent.id,
          planId
        });
        onSuccess();
      } catch (err) {
        toast({
          title: "Subscription Error",
          description: "Payment succeeded but subscription setup failed. Please contact support.",
          variant: "destructive",
        });
      }
    }

    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        disabled={!stripe || !elements || isLoading}
        className="w-full"
      >
        {isLoading ? 'Processing...' : 'Subscribe Now'}
      </Button>
    </form>
  );
}

export default function StripeSubscription() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [clientSecret, setClientSecret] = useState<string | null>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Get subscription plans
  const { data: plans = [], isLoading: plansLoading } = useQuery<SubscriptionPlan[]>({
    queryKey: ['/api/subscription/plans'],
    enabled: isAuthenticated
  });

  // Get current subscription status
  const { data: subscriptionStatus, isLoading: statusLoading } = useQuery({
    queryKey: ['/api/subscription/status'],
    enabled: isAuthenticated
  });

  // Create payment intent mutation
  const createPaymentIntentMutation = useMutation({
    mutationFn: async (planId: string) => {
      const response = await apiRequest('POST', '/api/subscription/create-payment-intent', { planId });
      return response;
    },
    onSuccess: (data) => {
      setClientSecret(data.clientSecret);
      toast({
        title: "Payment Setup Complete",
        description: "Please complete your payment to activate your subscription.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Setup Failed",
        description: error.message || "Failed to setup payment",
        variant: "destructive",
      });
    }
  });

  const handleSubscribe = (planId: string) => {
    setSelectedPlan(planId);
    createPaymentIntentMutation.mutate(planId);
  };

  const handlePaymentSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/subscription/status'] });
    setClientSecret(null);
    setSelectedPlan(null);
    toast({
      title: "Subscription Activated!",
      description: "Welcome to your new plan. You now have access to advanced features.",
    });
  };

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case 'basic':
        return <Star className="h-6 w-6 text-blue-500" />;
      case 'premium':
        return <Crown className="h-6 w-6 text-purple-500" />;
      case 'enterprise':
        return <Shield className="h-6 w-6 text-green-500" />;
      default:
        return <Zap className="h-6 w-6" />;
    }
  };

  const formatPrice = (price: number) => {
    return (price / 100).toFixed(2);
  };

  if (isLoading || plansLoading || statusLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const currentSubscription = subscriptionStatus?.subscription;
  const hasActiveSubscription = subscriptionStatus?.hasActiveSubscription;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <MobileNav />
        
        <main className="flex-1 p-6 lg:ml-64 lg:mr-0">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
                Upgrade Your Career Journey
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Choose the perfect plan to unlock advanced AI-powered career tools and accelerate your professional growth.
              </p>
            </div>

            <Tabs defaultValue="plans" className="w-full max-w-6xl mx-auto">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="plans">Choose Plan</TabsTrigger>
                <TabsTrigger value="current">Current Subscription</TabsTrigger>
              </TabsList>

              <TabsContent value="plans" className="space-y-8">
                {clientSecret && selectedPlan ? (
                  <div className="max-w-md mx-auto">
                    <Card>
                      <CardHeader>
                        <CardTitle>Complete Your Subscription</CardTitle>
                        <CardDescription>
                          Complete payment to activate your {plans.find(p => p.id === selectedPlan)?.name}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Elements 
                          stripe={stripePromise} 
                          options={{ 
                            clientSecret,
                            appearance: {
                              theme: 'stripe'
                            }
                          }}
                        >
                          <CheckoutForm 
                            planId={selectedPlan} 
                            clientSecret={clientSecret}
                            onSuccess={handlePaymentSuccess}
                          />
                        </Elements>
                        <Button 
                          variant="outline" 
                          onClick={() => {
                            setClientSecret(null);
                            setSelectedPlan(null);
                          }}
                          className="w-full mt-4"
                        >
                          Cancel
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-3 gap-6">
                    {plans.map((plan) => (
                      <Card 
                        key={plan.id} 
                        className={`relative transition-all duration-300 hover:shadow-xl ${
                          plan.id === 'premium' 
                            ? 'border-purple-200 dark:border-purple-700 shadow-lg transform scale-105' 
                            : 'hover:border-blue-200 dark:hover:border-blue-700'
                        }`}
                      >
                        {plan.id === 'premium' && (
                          <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-1">
                              Most Popular
                            </Badge>
                          </div>
                        )}
                        
                        <CardHeader className="text-center pb-4">
                          <div className="flex justify-center mb-4">
                            {getPlanIcon(plan.id)}
                          </div>
                          <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                          <CardDescription className="text-sm">{plan.description}</CardDescription>
                          <div className="mt-4">
                            <span className="text-4xl font-bold text-gray-900 dark:text-white">
                              ${formatPrice(plan.price)}
                            </span>
                            <span className="text-gray-600 dark:text-gray-400">/{plan.interval}</span>
                          </div>
                        </CardHeader>
                        
                        <CardContent className="space-y-6">
                          <ul className="space-y-3">
                            {plan.features.map((feature, index) => (
                              <li key={index} className="flex items-start gap-3">
                                <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                                <span className="text-sm text-gray-700 dark:text-gray-300">{feature}</span>
                              </li>
                            ))}
                          </ul>
                          
                          <Button 
                            onClick={() => handleSubscribe(plan.id)}
                            disabled={createPaymentIntentMutation.isPending || hasActiveSubscription}
                            className={`w-full ${
                              plan.id === 'premium' 
                                ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600' 
                                : ''
                            }`}
                          >
                            {createPaymentIntentMutation.isPending && selectedPlan === plan.id ? (
                              <div className="flex items-center gap-2">
                                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                                Setting up...
                              </div>
                            ) : hasActiveSubscription ? (
                              'Already Subscribed'
                            ) : (
                              `Subscribe to ${plan.name}`
                            )}
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="current" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Current Subscription Status</CardTitle>
                    <CardDescription>Manage your subscription and billing information</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {hasActiveSubscription ? (
                      <div className="space-y-4">
                        <div className="flex items-center gap-4">
                          <Badge variant="default" className="bg-green-500">Active</Badge>
                          <span className="font-semibold">{currentSubscription.planName}</span>
                        </div>
                        
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-gray-600 dark:text-gray-400">Subscription Start</p>
                            <p className="font-medium">
                              {new Date(currentSubscription.subscriptionStart).toLocaleDateString()}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600 dark:text-gray-400">Next Billing Date</p>
                            <p className="font-medium">
                              {new Date(currentSubscription.subscriptionEnd).toLocaleDateString()}
                            </p>
                          </div>
                        </div>

                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Payment ID</p>
                          <p className="font-mono text-sm">{currentSubscription.paymentId}</p>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <div className="mb-4">
                          <Star className="h-12 w-12 text-gray-400 mx-auto" />
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                          No Active Subscription
                        </h3>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">
                          Subscribe to a plan to unlock advanced career development tools.
                        </p>
                        <Button onClick={() => document.querySelector('[value="plans"]')?.click()}>
                          View Plans
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}