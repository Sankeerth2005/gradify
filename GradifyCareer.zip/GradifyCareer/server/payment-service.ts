import Stripe from 'stripe';

if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('Stripe secret key not found. Payment features will be disabled.');
}

const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: '2023-10-16',
    })
  : null;

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  interval: 'monthly' | 'yearly';
  features: string[];
  description: string;
}

export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: 'basic',
    name: 'Basic Plan',
    price: 999, // $9.99 in cents
    currency: 'USD',
    interval: 'monthly',
    features: [
      'AI Resume Builder',
      'Basic Cover Letter Generator',
      '5 Resume Downloads per month',
      'Basic ATS Score',
      'Email Support'
    ],
    description: 'Perfect for job seekers starting their career journey'
  },
  {
    id: 'premium',
    name: 'Premium Plan',
    price: 1999, // $19.99 in cents
    currency: 'USD',
    interval: 'monthly',
    features: [
      'Advanced AI Resume Analysis',
      'Unlimited Resume & Cover Letter Generation',
      'Personalized Career Roadmaps',
      'AI Interview Preparation',
      'LinkedIn Profile Optimization',
      'Priority Support',
      'Advanced ATS Optimization'
    ],
    description: 'Comprehensive career advancement tools for professionals'
  },
  {
    id: 'enterprise',
    name: 'Enterprise Plan',
    price: 4999, // $49.99 in cents
    currency: 'USD',
    interval: 'monthly',
    features: [
      'All Premium Features',
      'Advanced ML Job Matching',
      'Custom Career Coaching',
      '1-on-1 Expert Sessions',
      'Advanced Analytics Dashboard',
      'API Access',
      'White-label Solutions',
      '24/7 Phone Support'
    ],
    description: 'Complete career development suite for enterprises'
  }
];

export class PaymentService {
  static async createPaymentIntent(amount: number, currency: string = 'USD') {
    if (!stripe) {
      throw new Error('Stripe not configured. Please add STRIPE_SECRET_KEY');
    }

    try {
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount), // amount in cents
        currency: currency.toLowerCase(),
        automatic_payment_methods: {
          enabled: true,
        },
      });

      return {
        clientSecret: paymentIntent.client_secret,
        id: paymentIntent.id
      };
    } catch (error) {
      console.error('Payment intent creation failed:', error);
      throw new Error('Failed to create payment intent');
    }
  }

  static async createSubscription(planId: string, customerId?: string) {
    if (!stripe) {
      throw new Error('Stripe not configured');
    }

    const plan = SUBSCRIPTION_PLANS.find(p => p.id === planId);
    if (!plan) {
      throw new Error('Invalid subscription plan');
    }

    try {
      // Create or retrieve customer
      let customer;
      if (customerId) {
        customer = await stripe.customers.retrieve(customerId);
      } else {
        customer = await stripe.customers.create({});
      }

      // Create subscription
      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price_data: {
            currency: plan.currency.toLowerCase(),
            product_data: {
              name: plan.name,
              description: plan.description,
            },
            unit_amount: plan.price,
            recurring: {
              interval: plan.interval === 'monthly' ? 'month' : 'year',
            },
          },
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });

      return {
        subscription,
        plan,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret
      };
    } catch (error) {
      console.error('Subscription creation failed:', error);
      throw new Error('Failed to create subscription');
    }
  }

  static async cancelSubscription(subscriptionId: string) {
    if (!stripe) {
      throw new Error('Stripe not configured');
    }

    try {
      const subscription = await stripe.subscriptions.cancel(subscriptionId);
      return subscription;
    } catch (error) {
      console.error('Subscription cancellation failed:', error);
      throw new Error('Failed to cancel subscription');
    }
  }

  static async getPaymentIntent(paymentIntentId: string) {
    if (!stripe) {
      throw new Error('Stripe not configured');
    }

    try {
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      return paymentIntent;
    } catch (error) {
      console.error('Failed to fetch payment intent:', error);
      throw new Error('Failed to get payment details');
    }
  }

  static getPublicKey() {
    return process.env.VITE_STRIPE_PUBLIC_KEY;
  }

  static getPlanById(planId: string): SubscriptionPlan | undefined {
    return SUBSCRIPTION_PLANS.find(plan => plan.id === planId);
  }

  static getAllPlans(): SubscriptionPlan[] {
    return SUBSCRIPTION_PLANS;
  }
}