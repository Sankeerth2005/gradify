import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { AIServices } from "./ai-services";
import { PaymentService, SUBSCRIPTION_PLANS } from "./payment-service";
import { 
  insertUserProfileSchema, 
  insertResumeSchema,
  insertCoverLetterSchema,
  insertCareerRoadmapSchema,
  insertInterviewSessionSchema,
  insertStudyRoomSchema,
  insertUserTaskSchema,
  insertUserBadgeSchema,
  insertUserActivitySchema,
  insertResearchDocumentSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User profile routes
  app.get('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.post('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profileData = insertUserProfileSchema.parse(req.body);
      
      const existing = await storage.getUserProfile(userId);
      let profile;
      
      if (existing) {
        profile = await storage.updateUserProfile(userId, profileData);
      } else {
        profile = await storage.createUserProfile({ ...profileData, userId });
      }
      
      res.json(profile);
    } catch (error) {
      console.error("Error saving profile:", error);
      res.status(400).json({ message: "Failed to save profile" });
    }
  });

  // Advanced AI Resume routes
  app.get('/api/resumes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resumes = await storage.getResumes(userId);
      res.json(resumes);
    } catch (error) {
      console.error("Error fetching resumes:", error);
      res.status(500).json({ message: "Failed to fetch resumes" });
    }
  });

  app.post('/api/resumes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resumeData = insertResumeSchema.parse(req.body);
      const resume = await storage.createResume({ ...resumeData, userId });
      
      // Create activity
      await storage.createActivity({
        userId,
        activityType: 'resume_created',
        title: 'Resume created',
        description: `You created a new resume: ${resume.title}`,
        metadata: { resumeId: resume.id }
      });
      
      res.json(resume);
    } catch (error) {
      console.error("Error creating resume:", error);
      res.status(400).json({ message: "Failed to create resume" });
    }
  });

  app.get('/api/resumes/:id', isAuthenticated, async (req: any, res) => {
    try {
      const resume = await storage.getResume(req.params.id);
      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }
      res.json(resume);
    } catch (error) {
      console.error("Error fetching resume:", error);
      res.status(500).json({ message: "Failed to fetch resume" });
    }
  });

  app.put('/api/resumes/:id', isAuthenticated, async (req: any, res) => {
    try {
      const resumeData = insertResumeSchema.partial().parse(req.body);
      const resume = await storage.updateResume(req.params.id, resumeData);
      res.json(resume);
    } catch (error) {
      console.error("Error updating resume:", error);
      res.status(400).json({ message: "Failed to update resume" });
    }
  });

  app.delete('/api/resumes/:id', isAuthenticated, async (req: any, res) => {
    try {
      await storage.deleteResume(req.params.id);
      res.json({ message: "Resume deleted successfully" });
    } catch (error) {
      console.error("Error deleting resume:", error);
      res.status(500).json({ message: "Failed to delete resume" });
    }
  });

  // Cover letter routes
  app.get('/api/cover-letters', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const coverLetters = await storage.getCoverLetters(userId);
      res.json(coverLetters);
    } catch (error) {
      console.error("Error fetching cover letters:", error);
      res.status(500).json({ message: "Failed to fetch cover letters" });
    }
  });

  app.post('/api/cover-letters', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const coverLetterData = insertCoverLetterSchema.parse(req.body);
      const coverLetter = await storage.createCoverLetter({ ...coverLetterData, userId });
      res.json(coverLetter);
    } catch (error) {
      console.error("Error creating cover letter:", error);
      res.status(400).json({ message: "Failed to create cover letter" });
    }
  });

  // Career roadmap routes
  app.get('/api/roadmaps', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const roadmaps = await storage.getCareerRoadmaps(userId);
      res.json(roadmaps);
    } catch (error) {
      console.error("Error fetching roadmaps:", error);
      res.status(500).json({ message: "Failed to fetch roadmaps" });
    }
  });

  app.post('/api/roadmaps', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const roadmapData = insertCareerRoadmapSchema.parse(req.body);
      const roadmap = await storage.createCareerRoadmap({ ...roadmapData, userId });
      res.json(roadmap);
    } catch (error) {
      console.error("Error creating roadmap:", error);
      res.status(400).json({ message: "Failed to create roadmap" });
    }
  });

  app.put('/api/roadmaps/:id', isAuthenticated, async (req: any, res) => {
    try {
      const roadmapData = insertCareerRoadmapSchema.partial().parse(req.body);
      const roadmap = await storage.updateCareerRoadmap(req.params.id, roadmapData);
      res.json(roadmap);
    } catch (error) {
      console.error("Error updating roadmap:", error);
      res.status(400).json({ message: "Failed to update roadmap" });
    }
  });

  // Interview session routes
  app.get('/api/interview-sessions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessions = await storage.getInterviewSessions(userId);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching interview sessions:", error);
      res.status(500).json({ message: "Failed to fetch interview sessions" });
    }
  });

  app.post('/api/interview-sessions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionData = insertInterviewSessionSchema.parse(req.body);
      const session = await storage.createInterviewSession({ ...sessionData, userId });
      res.json(session);
    } catch (error) {
      console.error("Error creating interview session:", error);
      res.status(400).json({ message: "Failed to create interview session" });
    }
  });

  app.put('/api/interview-sessions/:id', isAuthenticated, async (req: any, res) => {
    try {
      const sessionData = insertInterviewSessionSchema.partial().parse(req.body);
      const session = await storage.updateInterviewSession(req.params.id, sessionData);
      res.json(session);
    } catch (error) {
      console.error("Error updating interview session:", error);
      res.status(400).json({ message: "Failed to update interview session" });
    }
  });

  // Study room routes
  app.get('/api/study-rooms', isAuthenticated, async (req: any, res) => {
    try {
      const rooms = await storage.getStudyRooms();
      res.json(rooms);
    } catch (error) {
      console.error("Error fetching study rooms:", error);
      res.status(500).json({ message: "Failed to fetch study rooms" });
    }
  });

  app.get('/api/study-rooms/my', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const rooms = await storage.getUserStudyRooms(userId);
      res.json(rooms);
    } catch (error) {
      console.error("Error fetching user study rooms:", error);
      res.status(500).json({ message: "Failed to fetch user study rooms" });
    }
  });

  app.post('/api/study-rooms', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const roomData = insertStudyRoomSchema.parse(req.body);
      const room = await storage.createStudyRoom({ ...roomData, ownerId: userId });
      res.json(room);
    } catch (error) {
      console.error("Error creating study room:", error);
      res.status(400).json({ message: "Failed to create study room" });
    }
  });

  app.post('/api/study-rooms/:id/join', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.joinStudyRoom(req.params.id, userId);
      res.json({ message: "Joined study room successfully" });
    } catch (error) {
      console.error("Error joining study room:", error);
      res.status(400).json({ message: "Failed to join study room" });
    }
  });

  app.post('/api/study-rooms/:id/leave', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.leaveStudyRoom(req.params.id, userId);
      res.json({ message: "Left study room successfully" });
    } catch (error) {
      console.error("Error leaving study room:", error);
      res.status(400).json({ message: "Failed to leave study room" });
    }
  });

  // Task routes
  app.get('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tasks = await storage.getUserTasks(userId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskData = insertUserTaskSchema.parse(req.body);
      const task = await storage.createUserTask({ ...taskData, userId });
      res.json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(400).json({ message: "Failed to create task" });
    }
  });

  app.put('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const taskData = insertUserTaskSchema.partial().parse(req.body);
      const task = await storage.updateUserTask(req.params.id, taskData);
      
      // Award badge if task completed
      if (taskData.status === 'completed') {
        const userId = req.user.claims.sub;
        await storage.awardBadge({
          userId,
          badgeType: 'task_completed',
          badgeName: 'Task Master',
          description: 'Completed a task'
        });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(400).json({ message: "Failed to update task" });
    }
  });

  // Badge routes
  app.get('/api/badges', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const badges = await storage.getUserBadges(userId);
      res.json(badges);
    } catch (error) {
      console.error("Error fetching badges:", error);
      res.status(500).json({ message: "Failed to fetch badges" });
    }
  });

  // Activity routes
  app.get('/api/activities', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const activities = await storage.getUserActivities(userId);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Research document routes
  app.get('/api/research-documents', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const documents = await storage.getResearchDocuments(userId);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching research documents:", error);
      res.status(500).json({ message: "Failed to fetch research documents" });
    }
  });

  app.post('/api/research-documents', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const docData = insertResearchDocumentSchema.parse(req.body);
      const document = await storage.createResearchDocument({ ...docData, userId });
      res.json(document);
    } catch (error) {
      console.error("Error creating research document:", error);
      res.status(400).json({ message: "Failed to create research document" });
    }
  });

  app.put('/api/research-documents/:id', isAuthenticated, async (req: any, res) => {
    try {
      const docData = insertResearchDocumentSchema.partial().parse(req.body);
      const document = await storage.updateResearchDocument(req.params.id, docData);
      res.json(document);
    } catch (error) {
      console.error("Error updating research document:", error);
      res.status(400).json({ message: "Failed to update research document" });
    }
  });

  // Advanced AI-Powered Routes

  // Resume Analysis with AI
  app.post('/api/resumes/:id/analyze', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { jobDescription } = req.body;
      const userId = req.user.claims.sub;
      
      const resumes = await storage.getResumes(userId);
      const resume = resumes.find((r: any) => r.id === id);
      
      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }

      const analysis = await AIServices.analyzeResume(resume.content || '', jobDescription);
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing resume:", error);
      res.status(500).json({ message: "Failed to analyze resume" });
    }
  });

  // AI Cover Letter Generation
  app.post('/api/cover-letters/generate', isAuthenticated, async (req: any, res) => {
    try {
      const { resumeId, jobDescription, companyName } = req.body;
      const userId = req.user.claims.sub;
      
      const resumes = await storage.getResumes(userId);
      const resume = resumes.find((r: any) => r.id === resumeId);
      
      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }

      const coverLetter = await AIServices.generateCoverLetter(
        resume.content || '', 
        jobDescription, 
        companyName
      );

      const newCoverLetter = await storage.createCoverLetter({
        userId,
        title: `Cover Letter for ${companyName}`,
        content: coverLetter,
        companyName,
        jobDescription
      });

      res.json(newCoverLetter);
    } catch (error) {
      console.error("Error generating cover letter:", error);
      res.status(500).json({ message: "Failed to generate cover letter" });
    }
  });

  // AI Career Roadmap Generation
  app.post('/api/roadmaps/generate', isAuthenticated, async (req: any, res) => {
    try {
      const { currentRole, targetRole, experience, skills } = req.body;
      const userId = req.user.claims.sub;

      const roadmapData = await AIServices.generateCareerRoadmap(
        currentRole, 
        targetRole, 
        experience, 
        skills
      );

      const newRoadmap = await storage.createCareerRoadmap({
        userId,
        title: `${currentRole} to ${targetRole} Roadmap`,
        currentRole,
        targetRole,
        timeframe: roadmapData.timeframe,
        phases: JSON.stringify(roadmapData.phases),
        skills: skills,
        progress: 0
      });

      res.json({ roadmap: newRoadmap, data: roadmapData });
    } catch (error) {
      console.error("Error generating roadmap:", error);
      res.status(500).json({ message: "Failed to generate roadmap" });
    }
  });

  // AI Interview Preparation
  app.post('/api/interview-sessions/generate', isAuthenticated, async (req: any, res) => {
    try {
      const { jobDescription, difficulty } = req.body;
      const userId = req.user.claims.sub;

      const questions = await AIServices.generateInterviewQuestions(jobDescription, difficulty);

      const newSession = await storage.createInterviewSession({
        userId,
        type: 'ai-generated',
        difficulty,
        questions: JSON.stringify(questions),
        responses: JSON.stringify({}),
        score: null,
        feedback: null,
        duration: null
      });

      res.json({ session: newSession, questions });
    } catch (error) {
      console.error("Error generating interview questions:", error);
      res.status(500).json({ message: "Failed to generate interview questions" });
    }
  });

  // LinkedIn Profile Optimization
  app.post('/api/profile/optimize-linkedin', isAuthenticated, async (req: any, res) => {
    try {
      const { currentProfile, targetRole } = req.body;
      const userId = req.user.claims.sub;

      const optimization = await AIServices.optimizeLinkedInProfile(currentProfile, targetRole);
      res.json(optimization);
    } catch (error) {
      console.error("Error optimizing LinkedIn profile:", error);
      res.status(500).json({ message: "Failed to optimize LinkedIn profile" });
    }
  });

  // Advanced Plagiarism Check
  app.post('/api/research/plagiarism-check', isAuthenticated, async (req: any, res) => {
    try {
      const { text, title } = req.body;
      const userId = req.user.claims.sub;

      const analysis = await AIServices.checkPlagiarism(text);

      const document = await storage.createResearchDocument({
        userId,
        title: title || 'Plagiarism Check',
        content: text,
        type: 'plagiarism-check',
        originalityScore: analysis.originalityScore,
        wordCount: analysis.wordCount
      });

      res.json({ document, analysis });
    } catch (error) {
      console.error("Error checking plagiarism:", error);
      res.status(500).json({ message: "Failed to check plagiarism" });
    }
  });

  // AI Text Humanization
  app.post('/api/research/humanize-text', isAuthenticated, async (req: any, res) => {
    try {
      const { text } = req.body;

      const humanizedText = await AIServices.humanizeText(text);
      res.json({ originalText: text, humanizedText });
    } catch (error) {
      console.error("Error humanizing text:", error);
      res.status(500).json({ message: "Failed to humanize text" });
    }
  });

  // Payment and Subscription Routes

  // Get all subscription plans
  app.get('/api/subscription/plans', async (req, res) => {
    try {
      const plans = PaymentService.getAllPlans();
      res.json(plans);
    } catch (error) {
      console.error("Error fetching plans:", error);
      res.status(500).json({ message: "Failed to fetch subscription plans" });
    }
  });

  // Create payment intent for subscription
  app.post('/api/subscription/create-payment-intent', isAuthenticated, async (req: any, res) => {
    try {
      const { planId } = req.body;
      const plan = PaymentService.getPlanById(planId);
      
      if (!plan) {
        return res.status(400).json({ message: "Invalid plan selected" });
      }
      
      const paymentIntent = await PaymentService.createPaymentIntent(plan.price, plan.currency);
      res.json({
        clientSecret: paymentIntent.clientSecret,
        planId: plan.id,
        amount: plan.price,
        currency: plan.currency
      });
    } catch (error) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Failed to create payment intent" });
    }
  });

  // Confirm subscription payment
  app.post('/api/subscription/confirm', isAuthenticated, async (req: any, res) => {
    try {
      const { paymentIntentId, planId } = req.body;
      const userId = req.user.claims.sub;

      // Verify payment intent was successful
      const paymentIntent = await PaymentService.getPaymentIntent(paymentIntentId);
      
      if (paymentIntent.status === 'succeeded') {
        const plan = PaymentService.getPlanById(planId);
        if (plan) {
          await storage.updateUserSubscription(userId, {
            planId: plan.id,
            planName: plan.name,
            status: 'active',
            paymentId: paymentIntentId,
            subscriptionStart: new Date(),
            subscriptionEnd: new Date(Date.now() + (plan.interval === 'yearly' ? 365 : 30) * 24 * 60 * 60 * 1000)
          });
        }

        res.json({ success: true, message: "Subscription activated successfully" });
      } else {
        res.status(400).json({ success: false, message: "Payment not completed" });
      }
    } catch (error) {
      console.error("Error confirming subscription:", error);
      res.status(500).json({ message: "Failed to confirm subscription" });
    }
  });

  // Get user subscription status
  app.get('/api/subscription/status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      res.json({
        subscription: user?.subscription || null,
        hasActiveSubscription: user?.subscription?.status === 'active'
      });
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Failed to fetch subscription status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
