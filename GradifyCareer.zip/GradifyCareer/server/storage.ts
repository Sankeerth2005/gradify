import {
  users,
  userProfiles,
  resumes,
  coverLetters,
  careerRoadmaps,
  interviewSessions,
  studyRooms,
  studyRoomParticipants,
  userTasks,
  userBadges,
  userActivities,
  researchDocuments,
  type User,
  type UpsertUser,
  type UserProfile,
  type InsertUserProfile,
  type Resume,
  type InsertResume,
  type CoverLetter,
  type InsertCoverLetter,
  type CareerRoadmap,
  type InsertCareerRoadmap,
  type InterviewSession,
  type InsertInterviewSession,
  type StudyRoom,
  type InsertStudyRoom,
  type UserTask,
  type InsertUserTask,
  type UserBadge,
  type InsertUserBadge,
  type UserActivity,
  type InsertUserActivity,
  type ResearchDocument,
  type InsertResearchDocument,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // User profile operations
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile & { userId: string }): Promise<UserProfile>;
  updateUserProfile(userId: string, profile: Partial<InsertUserProfile>): Promise<UserProfile>;
  
  // Resume operations
  getResumes(userId: string): Promise<Resume[]>;
  getResume(id: string): Promise<Resume | undefined>;
  createResume(resume: InsertResume & { userId: string }): Promise<Resume>;
  updateResume(id: string, resume: Partial<InsertResume>): Promise<Resume>;
  deleteResume(id: string): Promise<void>;
  
  // Cover letter operations
  getCoverLetters(userId: string): Promise<CoverLetter[]>;
  createCoverLetter(coverLetter: InsertCoverLetter & { userId: string }): Promise<CoverLetter>;
  
  // Career roadmap operations
  getCareerRoadmaps(userId: string): Promise<CareerRoadmap[]>;
  createCareerRoadmap(roadmap: InsertCareerRoadmap & { userId: string }): Promise<CareerRoadmap>;
  updateCareerRoadmap(id: string, roadmap: Partial<InsertCareerRoadmap>): Promise<CareerRoadmap>;
  
  // Interview session operations
  getInterviewSessions(userId: string): Promise<InterviewSession[]>;
  createInterviewSession(session: InsertInterviewSession & { userId: string }): Promise<InterviewSession>;
  updateInterviewSession(id: string, session: Partial<InsertInterviewSession>): Promise<InterviewSession>;
  
  // Study room operations
  getStudyRooms(): Promise<StudyRoom[]>;
  getUserStudyRooms(userId: string): Promise<StudyRoom[]>;
  createStudyRoom(room: InsertStudyRoom & { ownerId: string }): Promise<StudyRoom>;
  joinStudyRoom(roomId: string, userId: string): Promise<void>;
  leaveStudyRoom(roomId: string, userId: string): Promise<void>;
  
  // Task operations
  getUserTasks(userId: string): Promise<UserTask[]>;
  createUserTask(task: InsertUserTask & { userId: string }): Promise<UserTask>;
  updateUserTask(id: string, task: Partial<InsertUserTask>): Promise<UserTask>;
  
  // Badge operations
  getUserBadges(userId: string): Promise<UserBadge[]>;
  awardBadge(badge: InsertUserBadge & { userId: string }): Promise<UserBadge>;
  
  // Activity operations
  getUserActivities(userId: string): Promise<UserActivity[]>;
  createActivity(activity: InsertUserActivity & { userId: string }): Promise<UserActivity>;
  
  // Research document operations
  getResearchDocuments(userId: string): Promise<ResearchDocument[]>;
  createResearchDocument(doc: InsertResearchDocument & { userId: string }): Promise<ResearchDocument>;
  updateResearchDocument(id: string, doc: Partial<InsertResearchDocument>): Promise<ResearchDocument>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // User profile operations
  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const [profile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    return profile;
  }

  async createUserProfile(profile: InsertUserProfile & { userId: string }): Promise<UserProfile> {
    const [created] = await db.insert(userProfiles).values(profile).returning();
    return created;
  }

  async updateUserProfile(userId: string, profile: Partial<InsertUserProfile>): Promise<UserProfile> {
    const [updated] = await db
      .update(userProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(userProfiles.userId, userId))
      .returning();
    return updated;
  }

  // Resume operations
  async getResumes(userId: string): Promise<Resume[]> {
    return await db.select().from(resumes).where(eq(resumes.userId, userId)).orderBy(desc(resumes.createdAt));
  }

  async getResume(id: string): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume;
  }

  async createResume(resume: InsertResume & { userId: string }): Promise<Resume> {
    const [created] = await db.insert(resumes).values(resume).returning();
    return created;
  }

  async updateResume(id: string, resume: Partial<InsertResume>): Promise<Resume> {
    const [updated] = await db
      .update(resumes)
      .set({ ...resume, updatedAt: new Date() })
      .where(eq(resumes.id, id))
      .returning();
    return updated;
  }

  async deleteResume(id: string): Promise<void> {
    await db.delete(resumes).where(eq(resumes.id, id));
  }

  // Cover letter operations
  async getCoverLetters(userId: string): Promise<CoverLetter[]> {
    return await db.select().from(coverLetters).where(eq(coverLetters.userId, userId)).orderBy(desc(coverLetters.createdAt));
  }

  async createCoverLetter(coverLetter: InsertCoverLetter & { userId: string }): Promise<CoverLetter> {
    const [created] = await db.insert(coverLetters).values(coverLetter).returning();
    return created;
  }

  // Career roadmap operations
  async getCareerRoadmaps(userId: string): Promise<CareerRoadmap[]> {
    return await db.select().from(careerRoadmaps).where(eq(careerRoadmaps.userId, userId)).orderBy(desc(careerRoadmaps.createdAt));
  }

  async createCareerRoadmap(roadmap: InsertCareerRoadmap & { userId: string }): Promise<CareerRoadmap> {
    const [created] = await db.insert(careerRoadmaps).values(roadmap).returning();
    return created;
  }

  async updateCareerRoadmap(id: string, roadmap: Partial<InsertCareerRoadmap>): Promise<CareerRoadmap> {
    const [updated] = await db
      .update(careerRoadmaps)
      .set({ ...roadmap, updatedAt: new Date() })
      .where(eq(careerRoadmaps.id, id))
      .returning();
    return updated;
  }

  // Interview session operations
  async getInterviewSessions(userId: string): Promise<InterviewSession[]> {
    return await db.select().from(interviewSessions).where(eq(interviewSessions.userId, userId)).orderBy(desc(interviewSessions.createdAt));
  }

  async createInterviewSession(session: InsertInterviewSession & { userId: string }): Promise<InterviewSession> {
    const [created] = await db.insert(interviewSessions).values(session).returning();
    return created;
  }

  async updateInterviewSession(id: string, session: Partial<InsertInterviewSession>): Promise<InterviewSession> {
    const [updated] = await db
      .update(interviewSessions)
      .set({ ...session, updatedAt: new Date() })
      .where(eq(interviewSessions.id, id))
      .returning();
    return updated;
  }

  // Study room operations
  async getStudyRooms(): Promise<StudyRoom[]> {
    return await db.select().from(studyRooms).where(eq(studyRooms.isActive, true)).orderBy(desc(studyRooms.createdAt));
  }

  async getUserStudyRooms(userId: string): Promise<StudyRoom[]> {
    return await db
      .select({ 
        id: studyRooms.id,
        name: studyRooms.name,
        description: studyRooms.description,
        topic: studyRooms.topic,
        tags: studyRooms.tags,
        ownerId: studyRooms.ownerId,
        maxParticipants: studyRooms.maxParticipants,
        currentParticipants: studyRooms.currentParticipants,
        isActive: studyRooms.isActive,
        createdAt: studyRooms.createdAt,
        updatedAt: studyRooms.updatedAt,
      })
      .from(studyRooms)
      .innerJoin(studyRoomParticipants, eq(studyRooms.id, studyRoomParticipants.roomId))
      .where(and(eq(studyRoomParticipants.userId, userId), eq(studyRooms.isActive, true)));
  }

  async createStudyRoom(room: InsertStudyRoom & { ownerId: string }): Promise<StudyRoom> {
    const [created] = await db.insert(studyRooms).values(room).returning();
    // Auto-join the owner to the room
    await db.insert(studyRoomParticipants).values({
      roomId: created.id,
      userId: room.ownerId,
    });
    return created;
  }

  async joinStudyRoom(roomId: string, userId: string): Promise<void> {
    await db.insert(studyRoomParticipants).values({
      roomId,
      userId,
    });
    // Update participant count
    const [room] = await db.select().from(studyRooms).where(eq(studyRooms.id, roomId));
    if (room) {
      await db
        .update(studyRooms)
        .set({ currentParticipants: (room.currentParticipants || 0) + 1 })
        .where(eq(studyRooms.id, roomId));
    }
  }

  async leaveStudyRoom(roomId: string, userId: string): Promise<void> {
    await db
      .delete(studyRoomParticipants)
      .where(and(eq(studyRoomParticipants.roomId, roomId), eq(studyRoomParticipants.userId, userId)));
    // Update participant count
    const [room] = await db.select().from(studyRooms).where(eq(studyRooms.id, roomId));
    if (room && room.currentParticipants && room.currentParticipants > 0) {
      await db
        .update(studyRooms)
        .set({ currentParticipants: room.currentParticipants - 1 })
        .where(eq(studyRooms.id, roomId));
    }
  }

  // Task operations
  async getUserTasks(userId: string): Promise<UserTask[]> {
    return await db.select().from(userTasks).where(eq(userTasks.userId, userId)).orderBy(desc(userTasks.createdAt));
  }

  async createUserTask(task: InsertUserTask & { userId: string }): Promise<UserTask> {
    const [created] = await db.insert(userTasks).values(task).returning();
    return created;
  }

  async updateUserTask(id: string, task: Partial<InsertUserTask>): Promise<UserTask> {
    const updateData = { ...task, updatedAt: new Date() };
    if (task.status === 'completed' && !task.completedAt) {
      updateData.completedAt = new Date();
    }
    const [updated] = await db
      .update(userTasks)
      .set(updateData)
      .where(eq(userTasks.id, id))
      .returning();
    return updated;
  }

  // Badge operations
  async getUserBadges(userId: string): Promise<UserBadge[]> {
    return await db.select().from(userBadges).where(eq(userBadges.userId, userId)).orderBy(desc(userBadges.earnedAt));
  }

  async awardBadge(badge: InsertUserBadge & { userId: string }): Promise<UserBadge> {
    const [created] = await db.insert(userBadges).values(badge).returning();
    return created;
  }

  // Activity operations
  async getUserActivities(userId: string): Promise<UserActivity[]> {
    return await db.select().from(userActivities).where(eq(userActivities.userId, userId)).orderBy(desc(userActivities.createdAt)).limit(20);
  }

  async createActivity(activity: InsertUserActivity & { userId: string }): Promise<UserActivity> {
    const [created] = await db.insert(userActivities).values(activity).returning();
    return created;
  }

  // Research document operations
  async getResearchDocuments(userId: string): Promise<ResearchDocument[]> {
    return await db.select().from(researchDocuments).where(eq(researchDocuments.userId, userId)).orderBy(desc(researchDocuments.createdAt));
  }

  async createResearchDocument(doc: InsertResearchDocument & { userId: string }): Promise<ResearchDocument> {
    const [created] = await db.insert(researchDocuments).values(doc).returning();
    return created;
  }

  async updateResearchDocument(id: string, doc: Partial<InsertResearchDocument>): Promise<ResearchDocument> {
    const [updated] = await db
      .update(researchDocuments)
      .set({ ...doc, updatedAt: new Date() })
      .where(eq(researchDocuments.id, id))
      .returning();
    return updated;
  }

  // Subscription operations
  async updateUserSubscription(userId: string, subscription: any): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        subscription: JSON.stringify(subscription),
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }
}

export const storage = new DatabaseStorage();
