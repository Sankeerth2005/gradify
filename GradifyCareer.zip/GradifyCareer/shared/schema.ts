import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  uuid
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  subscription: jsonb("subscription"), // Store subscription details
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User profiles with career preferences
export const userProfiles = pgTable("user_profiles", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  skills: text("skills").array(),
  education: jsonb("education"),
  careerGoals: text("career_goals"),
  experience: jsonb("experience"),
  resumeUrl: varchar("resume_url"),
  portfolioUrl: varchar("portfolio_url"),
  linkedinUrl: varchar("linkedin_url"),
  githubUrl: varchar("github_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Resumes
export const resumes = pgTable("resumes", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  title: varchar("title").notNull(),
  content: jsonb("content").notNull(),
  templateId: varchar("template_id").notNull(),
  atsScore: integer("ats_score"),
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Cover letters
export const coverLetters = pgTable("cover_letters", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  jobTitle: varchar("job_title"),
  companyName: varchar("company_name"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Career roadmaps
export const careerRoadmaps = pgTable("career_roadmaps", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  targetRole: varchar("target_role").notNull(),
  targetCompany: varchar("target_company"),
  steps: jsonb("steps").notNull(),
  currentStep: integer("current_step").default(0),
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Interview prep sessions
export const interviewSessions = pgTable("interview_sessions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  sessionType: varchar("session_type").notNull(), // 'dsa', 'behavioral', 'system_design'
  questions: jsonb("questions").notNull(),
  answers: jsonb("answers"),
  score: integer("score"),
  duration: integer("duration"), // in minutes
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Study rooms
export const studyRooms = pgTable("study_rooms", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  topic: varchar("topic").notNull(),
  tags: text("tags").array(),
  ownerId: varchar("owner_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  maxParticipants: integer("max_participants").default(10),
  currentParticipants: integer("current_participants").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Study room participants
export const studyRoomParticipants = pgTable("study_room_participants", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: uuid("room_id").references(() => studyRooms.id, { onDelete: "cascade" }).notNull(),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
});

// User tasks and milestones
export const userTasks = pgTable("user_tasks", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  category: varchar("category").notNull(), // 'career', 'study', 'networking'
  priority: varchar("priority").default('medium'), // 'low', 'medium', 'high'
  status: varchar("status").default('pending'), // 'pending', 'in_progress', 'completed'
  dueDate: timestamp("due_date"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User badges and achievements
export const userBadges = pgTable("user_badges", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  badgeType: varchar("badge_type").notNull(), // 'resume_champ', 'dsa_master', etc.
  badgeName: varchar("badge_name").notNull(),
  description: text("description"),
  iconUrl: varchar("icon_url"),
  earnedAt: timestamp("earned_at").defaultNow(),
});

// User activity feed
export const userActivities = pgTable("user_activities", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  activityType: varchar("activity_type").notNull(), // 'resume_created', 'badge_earned', 'study_joined'
  title: varchar("title").notNull(),
  description: text("description"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Research documents for plagiarism checking
export const researchDocuments = pgTable("research_documents", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  originalityScore: integer("originality_score"),
  plagiarismReport: jsonb("plagiarism_report"),
  wordCount: integer("word_count"),
  status: varchar("status").default('pending'), // 'pending', 'processed', 'failed'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Schema types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;
export type Resume = typeof resumes.$inferSelect;
export type InsertResume = typeof resumes.$inferInsert;
export type CoverLetter = typeof coverLetters.$inferSelect;
export type InsertCoverLetter = typeof coverLetters.$inferInsert;
export type CareerRoadmap = typeof careerRoadmaps.$inferSelect;
export type InsertCareerRoadmap = typeof careerRoadmaps.$inferInsert;
export type InterviewSession = typeof interviewSessions.$inferSelect;
export type InsertInterviewSession = typeof interviewSessions.$inferInsert;
export type StudyRoom = typeof studyRooms.$inferSelect;
export type InsertStudyRoom = typeof studyRooms.$inferInsert;
export type UserTask = typeof userTasks.$inferSelect;
export type InsertUserTask = typeof userTasks.$inferInsert;
export type UserBadge = typeof userBadges.$inferSelect;
export type InsertUserBadge = typeof userBadges.$inferInsert;
export type UserActivity = typeof userActivities.$inferSelect;
export type InsertUserActivity = typeof userActivities.$inferInsert;
export type ResearchDocument = typeof researchDocuments.$inferSelect;
export type InsertResearchDocument = typeof researchDocuments.$inferInsert;

// Insert schemas for validation
export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({ id: true, userId: true, createdAt: true, updatedAt: true });
export const insertResumeSchema = createInsertSchema(resumes).omit({ id: true, userId: true, createdAt: true, updatedAt: true });
export const insertCoverLetterSchema = createInsertSchema(coverLetters).omit({ id: true, userId: true, createdAt: true, updatedAt: true });
export const insertCareerRoadmapSchema = createInsertSchema(careerRoadmaps).omit({ id: true, userId: true, createdAt: true, updatedAt: true });
export const insertInterviewSessionSchema = createInsertSchema(interviewSessions).omit({ id: true, userId: true, createdAt: true, updatedAt: true });
export const insertStudyRoomSchema = createInsertSchema(studyRooms).omit({ id: true, ownerId: true, createdAt: true, updatedAt: true });
export const insertUserTaskSchema = createInsertSchema(userTasks).omit({ id: true, userId: true, createdAt: true, updatedAt: true });
export const insertUserBadgeSchema = createInsertSchema(userBadges).omit({ id: true, userId: true });
export const insertUserActivitySchema = createInsertSchema(userActivities).omit({ id: true, userId: true });
export const insertResearchDocumentSchema = createInsertSchema(researchDocuments).omit({ id: true, userId: true, createdAt: true, updatedAt: true });
